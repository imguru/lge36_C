#include "./header/race.h"


void race(){

	printf("Race\n");
}
