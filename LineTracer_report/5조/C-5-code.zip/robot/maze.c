#include <stdio.h>
#include "./header/maze.h"


void createMap(){
	printf("Maze : CreateMap\n");

}


void search(){
	printf("Maze : SearchMap\n");


}



