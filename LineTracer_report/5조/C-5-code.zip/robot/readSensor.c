/*
Hyeonwook.kim

   */

#include "./header/readSensor.h"

void init(){
	pinMode(Clock, OUTPUT);
	pinMode(Address, OUTPUT);
	pinMode(CS, OUTPUT);
	pinMode(DataOut, INPUT);
	pinMode(Button, INPUT);
}
void initRead(int * value){
	int i;
	for(i = 0 ;i < numSensors+1;++i){
		value[i]=0;
	}
}
void analRead(int * value){
	int i, j;
	initRead(value);
	for(j = 0; j < numSensors+1 ; ++j){
		digitalWrite(CS, LOW);
		for(i = 0; i < 4; ++i){
			if(((j) >> (3 - i)) & 0x01)
				digitalWrite(Address, HIGH);
			else
				digitalWrite(Address, LOW);
			delay(1);
			value[j] <<= 1;
			if(digitalRead(DataOut) == 1)
				value[j] |= 0x01;
			digitalWrite(Clock, HIGH);

			delay(1);
			digitalWrite(Clock, LOW);
		}
		for(i = 0; i < 6; ++i){
			value[j] <<= 1;
			if(digitalRead(DataOut) == 1)
				value[j] |= 0x01;
			digitalWrite(Clock, HIGH);
			delay(1);
			digitalWrite(Clock, LOW);
		}
		digitalWrite(CS, HIGH);
	}
#if 0
	for(i=0;i<=numSensors;i++)
		printf("%d ",value[i]);
	printf("\n");
#endif
	//printf("A");


}
void calibrate(int  * value, int * calibratedMin, int * calibratedMax){
	int max_sensor_values[numSensors] = {0, };
	int min_sensor_values[numSensors] = {0, };
	int i, j;
	for(j = 0; j < 10 ; ++j){
		analRead(value);
		for(i = 0 ; i<numSensors; ++i){
			if((j == 0) || max_sensor_values[i] < value[i+1])
				max_sensor_values[i] = value[i+1];
			if((j == 0) || min_sensor_values[i] > value[i+1])
				min_sensor_values[i] = value[i+1];
			//printf("value[%d] : %d\n", i+1, value[i+1]);
		}
		for(i = 0 ; i< numSensors; ++i){
			if(min_sensor_values[i] < calibratedMin[i])
				calibratedMin[i] = min_sensor_values[i];
			if(max_sensor_values[i] > calibratedMax[i])
				calibratedMax[i] = max_sensor_values[i];
		}
		//		for(i = 0 ; i< numSensors; ++i){
		//			printf("calmin[%d]:%d, calmax[%d]:%d",i,calibratedMin[i],i, calibratedMax[i]);
		//		}
		//		printf("\n");
		//		initRead(value);
	}
}
void readCalibrated(int * value, int * sensor_values, int * calibratedMin, int * calibratedMax){
	int	value1 = 0;
	int i, j;
	analRead(value);
	for(i = 0; i < numSensors; ++i){
		int denominator = calibratedMax[i] - calibratedMin[i];
		if(denominator != 0)
			value1 = (value[i+1] - calibratedMin[i])* 1000 / denominator;
		if(value1 < 0)
			value1 = 0;
		else if(value1 > 1000)
			value1 = 1000;
		//		printf("value:%d\n", value1);
		sensor_values[i] = value1;
		//		printf("sensor_value:%d\n", sensor_values[i]);
	}
	//	initRead(value);
}
//white_line = 1
void readLine(int white_line,int* value,  int * sensor_values, int *calibratedMin, int * calibratedMax, int last_value){
	readCalibrated(value, sensor_values, calibratedMin, calibratedMax);
	int avg = 0;
	int	sum = 0;
	int	on_line = 0;
	for(int i = 0; i < numSensors; ++i){
		int value = sensor_values[i];
		if(white_line)
			value = 1000-value;
		if(value > 200)
			on_line = 1;
		if(value > 50){
			avg += value * (i * 1000);
			sum += value; 
		}
	}
	if(on_line != 1){
		// If it last read to the left of center, return 0.
		if(last_value < (numSensors - 1)*1000/2)
			//print("left")
			last_value = 0;
		// If it last read to the right of center, return the max.
		else
			//print("right")
			last_value = (numSensors - 1)*1000;
	}
	else last_value = avg/sum;
}
