#include "./header/routine.h"
#include "./header/mainController.h"
#define SPEED 10

void stop(){
	printf("stop\n");
	digitalWrite(RIGHT1, 0);
	digitalWrite(RIGHT2, 0);
	digitalWrite(LEFT1, 0);
	digitalWrite(LEFT2, 0);
	softPwmWrite(ENA, 0);
	softPwmWrite(ENB, 0);
}


void forward(){
	printf("forward\n");
	digitalWrite(RIGHT1, 1);
	digitalWrite(RIGHT2, 0);
	digitalWrite(LEFT1, 1);
	digitalWrite(LEFT2, 0);
	softPwmWrite(ENA, SPEED);
	softPwmWrite(ENB, SPEED);


}


void backward(){
	printf("backward\n");
	digitalWrite(RIGHT1, 0);
	digitalWrite(RIGHT2, 1);
	digitalWrite(LEFT1, 0);
	digitalWrite(LEFT2, 1);
	softPwmWrite(ENA, SPEED);
	softPwmWrite(ENB, SPEED);

}

void left(){
	printf("left\n");
	digitalWrite(RIGHT1, 0);
	digitalWrite(RIGHT2, 1);
	digitalWrite(LEFT1, 1);
	digitalWrite(LEFT2, 0);
	softPwmWrite(ENA, SPEED);
	softPwmWrite(ENB, SPEED);


}

void right(){
	printf("right\n");
	digitalWrite(RIGHT1, 1);
	digitalWrite(RIGHT2, 0);
	digitalWrite(LEFT1, 0);
	digitalWrite(LEFT2, 1);
	softPwmWrite(ENA, SPEED);
	softPwmWrite(ENB, SPEED);


}
