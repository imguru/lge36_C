#include "./header/mainController.h"
#include "./header/routine.h"
#include "./header/maze.h"
#include "./header/race.h"
#include "./header/readSensor.h"
#include "../ip.h"

int modeStatus=0;
int leftSpeed=0;
int rightSpeed=0;
int sensor_values[numSensors] = {0, };



pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int main(){

#if 1 
		wiringPiSetup();

		pinMode(ENA , OUTPUT);
		pinMode(LEFT1 , OUTPUT);
		pinMode(LEFT2 , OUTPUT);
		pinMode(ENB , OUTPUT);
		pinMode(RIGHT1 , OUTPUT);
		pinMode(RIGHT2 , OUTPUT);
		pinMode(JOYA, INPUT);
		pinMode(JOYB, INPUT);
		pinMode(JOYC, INPUT);
		pinMode(JOYD, INPUT);

		softPwmCreate(ENA, 0, 100);
		softPwmCreate(ENB, 0, 100);
		wiringPiISR(JOY, INT_EDGE_FALLING, setJoy);
		mcp3422Setup(400, 0x6a, 0, 0);
#endif

		pthread_t motorT;
		pthread_t monitorT;
		pthread_t networkAccept;
		pthread_t sensorT;

		pthread_create(&motorT, 0, motorThread, 0);
		pthread_detach(motorT);
		pthread_create(&monitorT,0, monitorThread, 0);
		pthread_detach(monitorT);
		pthread_create(&sensorT, 0, sensorThread, 0);
		pthread_detach(sensorT);
		pthread_create(&networkAccept, 0, netThread, 0);
		pthread_detach(networkAccept);


		while(1){}
#if 0
	while(1){
		switch(modeStatus){
			case 0:
				printf("Mode Status : Routine Stop\n");
				setMotorLeft(0);
				setMotorRight(0);
				break;

			case 1:
				printf("Mode Status : Routine left\n");
				setMotorLeft(50);	
				setMotorRight(30);
				break;

			case 2:
				printf("Mode Status : Routine forward\n");
				setMotorLeft(20);
				setMotorRight(30);
				break;
			
			case 3:
				printf("Mode Status : Routine right\n");
				setMotorLeft(20);
				setMotorRight(80);
				break;

		}
	}
#endif
	return 0;
}



void *motorThread(void *arg){
#if 0
	while(1){
		digitalWrite(RIGHT1, 1);
		digitalWrite(RIGHT2, 0);
		digitalWrite(LEFT1, 1);
		digitalWrite(LEFT2, 0);
		softPwmWrite(ENA, leftSpeed);
		softPwmWrite(ENB, rightSpeed);
	}
#endif
}


void *sensorThread(void *arg){
	int value[numSensors+1] = {0, };
	int calibratedMin[5]={0, };
	int calibratedMax[5]={0, };
	int last_value=0;
	int i;
	for(i = 0; i<numSensors;++i){
		calibratedMin[i] = 1023;
	}
	init();

		calibrate(value, calibratedMin, calibratedMax);
	while(1){
		readCalibrated(value, sensor_values, calibratedMin, calibratedMax); 
	}
}



void *monitorThread(void *arg){
	int csock = (intptr_t)arg;  // !!
	int ret;
	int buf[5];
	int i;
	
	while ((ret = read(csock, buf, sizeof buf)) > 0) {
		for(i=0; i<5; i++){
			buf[i] = sensor_values[i];
		}
		write(csock, buf, sizeof buf);
	
	}
	close(csock);
	printf("클라이언트와 연결이 종료되었습니다..\n");


}


void *netThread(void *arg){
	int ssock = socket(PF_INET, SOCK_STREAM, 0);

	int option = 1;
	setsockopt(ssock, SOL_SOCKET, SO_REUSEADDR, &option, sizeof option);

	struct sockaddr_in saddr = {0, };
	saddr.sin_family = AF_INET;
	saddr.sin_addr.s_addr = INADDR_ANY;
	saddr.sin_port = htons(5000);
	bind(ssock, (struct sockaddr *)&saddr, sizeof saddr);

	listen(ssock, SOMAXCONN); 

	while (1) {
		struct sockaddr_in caddr = {0, };
		socklen_t caddrlen = sizeof caddr;
		int csock = accept(ssock, (struct sockaddr *)&caddr, &caddrlen);

		printf("client: %s\n", inet_ntoa(caddr.sin_addr));

		pthread_t thread;
		intptr_t arg = csock;
		pthread_create(&thread, NULL, monitorThread, (void *)arg);
		pthread_detach(thread);
	}

	close(ssock);

}
void setModeStatus(int status){
	modeStatus = status;
}


void setMotorLeft(int speed){
	pthread_mutex_lock(&mutex);
	leftSpeed = speed;
	pthread_mutex_unlock(&mutex);
}

void setMotorRight(int speed){
	pthread_mutex_lock(&mutex);
	rightSpeed = speed;
	pthread_mutex_unlock(&mutex);
}


void setJoy(){
	int status = (modeStatus+1)%4;
	setModeStatus(status);
}


