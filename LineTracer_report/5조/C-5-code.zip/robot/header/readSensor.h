
#include <wiringPi.h>
#include <stdio.h>
#include <unistd.h>
#define numSensors 5
#define CS 21 
#define Clock 6
#define Address 5
#define DataOut 4
#define Button 11


void init();
void analRead(int * value);
void calibrate(int  * value, int * calibratedMin, int * calibratedMax);
void readCalibrated(int * value, int * sensor_values, int * calibratedMin, int * calibratedMax);
void readLine(int white_line,int* value,  int * sensor_values, int *calibratedMin, int * calibratedMax, int last_value);

