#include <stdio.h>

void createMap();
void search();
