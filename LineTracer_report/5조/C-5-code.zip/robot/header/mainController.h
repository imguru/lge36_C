#include <stdio.h>
#include <pthread.h>
#include <wiringPi.h>
#include <mcp3422.h>
#include <softPwm.h>
#include <unistd.h>

#include <sys/types.h>     
#include <sys/socket.h>
#include <arpa/inet.h>


#define ENA 22
#define RIGHT1 23
#define RIGHT2 26

#define ENB 25
#define LEFT1 29
#define LEFT2 28

#define JOY 11
#define JOYA 10
#define JOYB 12
#define JOYC 13
#define JOYD 14


void *motorThread(void *arg);
void *sensorThread(void *arg);
void *monitorThread(void *arg);
void *netThread(void *arg);
void setModeStatus(int status);
void setMotorLeft(int speed);
void setMotorRight(int speed);
void setJoy();
