#include <stdio.h>



void stop();
void forward();
void backward();
void left();
void right();

