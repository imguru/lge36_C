
//wireless
#if 0
	#define ADDR  "192.168.137.100"
#endif


//wired rasp
#if 0
	#define ADDR "192.168.0.55"
#endif


//monitor ubuntu
#if 0
	#define ADDRMONITOR "192.168.56.100"
#endif



//monitor gnuplot
#if 1
	#define ADDRMONITOR "192.168.0.245"
#endif
