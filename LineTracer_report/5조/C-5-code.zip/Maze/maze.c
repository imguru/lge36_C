#include <stdio.h>
#include "lineMaze.h"
//#define WHITE 1000
//#define BLACK 0
#define NO_LINE 0
#define RIGHT_TURN 100
#define LEFT_TURN 200
#define CONT_LINE 300
#define FOLLOWING_LINE 400 
//------1inch만큼 더 하기
void runExtraInch(void)
{
	motorPIDcontrol();
	delay(extraInch);
	motorStop();
}
//------turn하기 위해 좀만 저 가기
void goAndTurn(int direction, int degrees)
{
	motorPIDcontrol();
	delay(adjGoAndTurn);
	motorTurn(direction, degrees);
}
/*
//-------상태에 따른 동작
void loop()
{
	readLFSsensors();
	switch (mode)
	{
		case NO_LINE:
			motorStop();
			goAndTurn (LEFT, 180);
			break;
		case CONT_LINE:
			runExtraInch();
			readLFSsensors();
			if (mode == CONT_LINE) mazeEnd();
			else goAndTurn (LEFT, 90); // or it is a "T" or "Cross"). In both cases, goes to LEFT
			break;
		case RIGHT_TURN:
			runExtraInch();
			readLFSsensors();
			if (mode == NO_LINE) goAndTurn (RIGHT, 90);
			break;
		case LEFT_TURN:
			goAndTurn (LEFT, 90);
			break;
		case FOLLOWING_LINE:
			followingLine();
			break;
			}
			}
 */
char path[100] = " ";
unsigned char pathLength = 0; // the length of the path
int pathIndex = 0; // used to reach an specific array element.

unsigned int status = 0; // solving = 0; reach Maze End = 1

void recIntersection(char direction)
{
	path[pathLength] = direction; // Store the intersection in the path variable.
	pathLength ++;
	simplifyPath(); // Simplify the learned path.
}

void simplifyPath()
{
	// only simplify the path if the second-to-last turn was a 'B'
	if(pathLength < 3 || path[pathLength-2] != 'B')
		return;
	int totalAngle = 0;
	int i;
	for(i=1;i<=3;i++)
	{
		switch(path[pathLength-i])
		{
			case 'R':
				totalAngle += 90;
				break;
			case 'L':
				totalAngle += 270;
				break;
			case 'B':
				totalAngle += 180;
				break;
		}
	}
	// Get the angle as a number between 0 and 360 degrees.
	totalAngle = totalAngle % 360;
	// Replace all of those turns with a single one.
	switch(totalAngle)
	{
		case 0:
			path[pathLength - 3] = 'S';
			break;
		case 90:
			path[pathLength - 3] = 'R';
			break;
		case 180:
			path[pathLength - 3] = 'B';
			break;
		case 270:
			path[pathLength - 3] = 'L';
			break;
	}
	// The path is now two steps shorter.
	pathLength -= 2;

} 
//------------미로 학습
void mazeSolve(void)
{
	while (!status)
	{
		readLFSsensors();  
		switch (mode)
		{   
			case NO_LINE:  
				motorStop();
				goAndTurn (LEFT, 180);
				recIntersection('B');
				break;

			case CONT_LINE: 
				runExtraInch();
				readLFSsensors();
				if (mode != CONT_LINE) {goAndTurn (LEFT, 90); recIntersection('L');} // or it is a "T" or "Cross"). In both cases, goes to LEFT
				else mazeEnd(); 
				break;

			case RIGHT_TURN: 
				runExtraInch();
				readLFSsensors();
				if (mode == NO_LINE) {goAndTurn (RIGHT, 90); recIntersection('R');}
				else recIntersection('S');
				break;   

			case LEFT_TURN: 
				goAndTurn (LEFT, 90); 
				recIntersection('L');
				break;   

			case FOLLOWING_LINE: 
				followingLine();
				break;      

		}
	}
}


void mazeOptimization (void)
{
	while (!status)
	{
		readLFSsensors();  
		switch (mode)
		{
			case FOLLOWING_LINE:
				followingLine();
				break;    
			case CONT_LINE:
				if (pathIndex >= pathLength) mazeEnd (); 
				else {mazeTurn (path[pathIndex]); pathIndex++;}
				break;  
			case LEFT_TURN:
				if (pathIndex >= pathLength) mazeEnd (); 
				else {mazeTurn (path[pathIndex]); pathIndex++;}
				break;  
			case RIGHT_TURN:
				if (pathIndex >= pathLength) mazeEnd (); 
				else {mazeTurn (path[pathIndex]); pathIndex++;}
				break;   
		}    
	}  
}
void mazeTurn (char dir) 
{
	switch(dir)
	{
		case 'L': // Turn Left
			goAndTurn (LEFT, 90);      
			break;   

		case 'R': // Turn Right
			goAndTurn (RIGHT, 90);     
			break;   

		case 'B': // Turn Back
			goAndTurn (RIGHT, 800);     
			break;   

		case 'S': // Go Straight
			runExtraInch(); 
			break;
	}
}
//*****메인 프로그램******
void loop() 
{
	ledBlink(1);
	readLFSsensors(); 

	mazeSolve(); // First pass to solve the maze
	ledBlink(2);
	while (digitalRead(buttonPin)) { }
	pathIndex = 0;
	status = 0;

	mazeOptimization(); // Second Pass: run the maze as fast as possible
	ledBlink(3);
	while (digitalRead(buttonPin) { }
	mode = STOPPED;
	status = 0; // 1st pass
	pathIndex = 0;
	pathLength = 0;
}

