#include <stdio.h>
#include "readSensor.h"
//#define WHITE 1000
//#define BLACK 0
#define NO_LINE 0
#define RIGHT_TURN 100
#define LEFT_TURN 200
#define CONT_LINE 300
#define FOLLOWING_LINE 400 

void readLFSensors(int * sensor_values){
	int mode = 0;//동작
	int error = 0;//에러 종류i
	//흰색  = 1000, 까만색 = 0
	int black=0 ;//캘리브레이션한 값
	int white=1000;
#if 0
	int i;
	//센서 값 확인
	for(i=0; i<5;++i){
		printf("sensor[%d]: %d\t", i+1, LFSensor[i]);
	}
	printf("\n");
#endif
	
	
	//--------오른쪽 길있음
	if((LFSensor[0] == white) && (LFSensor[1] == white) && (LFSensor[4] ==  1)){
		mode = RIGHT_TURN;
		error = 0;
	}
	//--------왼쪽길 있음
	else if((LFSensor[0] == black) && (LFSensor[3] == white) && (LFSensor[4] == white)){
		mode = LEFT_TURN;
		error = 0;
	}
	//--------라인 밖
	else if((LFSensor[0] == white) && (LFSensor[1] == white) && (LFSensor[2] == white)&& (LFSensor[3] == white) && (LFSensor[4] == white)){
		mode = NO_LINE;
		error = 0;
	}
	//--------도착지
	else if((LFSensor[0] == black) && (LFSensor[1] == black) && (LFSensor[2] == black)	&& (LFSensor[3] == BLACK) && (LFSensor[4] == BLACK)){
		mode = CONT_LINE;
		error = 0;
	}

	//--------직진길 하나
	else if((LFSensor[0] == white) && (LFSensor[1] == white) && (LFSensor[2] == white) && (LFSensor[3] == black) && (LFSensor[4] == white)){
		mode = FOLLOWING_LINE;
		error = 2;
	}
	else if((LFSensor[0] == white) && (LFSensor[1] == white) && (LFSensor[2] == black) 	&& (LFSensor[3] == black) && (LFSensor[4] == white)){
		mode = FOLLOWING_LINE;
		error = 1;
	}
	else if((LFSensor[0] == white) && (LFSensor[1] == white) && (LFSensor[2] == black) && (LFSensor[3] == white) && (LFSensor[4] == white)){
		mode = FOLLOWING_LINE;
		error = 0;
	}
	else if((LFSensor[0] == white) && (LFSensor[1] == black) && (LFSensor[2] == black) && (LFSensor[3] == white) && (LFSensor[4] == white)){
		mode = FOLLOWING_LINE;
		error = -1;
	}
	else if((LFSensor[0] == white) && (LFSensor[1] == black) && (LFSensor[2] == white) && (LFSensor[3] == white) && (LFSensor[4] == white)){
		mode = FOLLOWING_LINE;
		error = -2;
	}
}
