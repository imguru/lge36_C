#ifndef _LINE_MAZE_H
#define _LINE_MAZE_H


void readLFSensors(int * sensor_values);

#endif
