#!/bin/bash

`git add .`
`git commit -m \"a\"`
`git push origin master`
echo "yesul.min"
echo "@lgeuser34@#"

