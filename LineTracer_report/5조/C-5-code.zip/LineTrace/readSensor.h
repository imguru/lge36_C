#ifndef _READ_SENSOR_H
#define _READ_SENSOR_H

void init();
void analRead(int * value);
void calibrate(int  * value, int * calibratedMin, int * calibratedMax);
void readCalibrated(int * value, int * sensor_values, int * calibratedMin, int * calibratedMax);
int readLine(int white_line,int* value,  int * sensor_values, int *calibratedMin, int * calibratedMax);

#endif
