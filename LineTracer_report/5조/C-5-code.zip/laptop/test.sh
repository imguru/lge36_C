#! /bin/bash

for (( i=0; i<100000; ++i)); do
	echo 0 $i > ./data.dat
	echo 0.5 $i >> ./data.dat
        echo 1 $i >> ./data.dat
	echo 1.5 $i >> ./data.dat	
	echo 2 $i >> ./data.dat	
	sleep 0.1	
done
