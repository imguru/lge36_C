#include <unistd.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <stdio.h>
#include "../ip.h"


void getData(int csock){
	int buf[5];
	write(csock, buf, 1);

	read(csock, buf, sizeof buf);
	printf("%d\n", buf[0]);
	printf("%d\n", buf[1]);
	printf("%d\n", buf[2]);
	printf("%d\n", buf[3]);
	printf("%d\n", buf[4]);
	printf("\n");

	FILE *fp = fopen("./data.dat", "w");
	fprintf(fp, "0 %d\n", buf[0]);
	fprintf(fp, "0.5 %d\n", buf[1]);
	fprintf(fp, "1 %d\n", buf[2]);
	fprintf(fp, "1.5 %d\n", buf[3]);
	fprintf(fp, "2 %d\n", buf[4]);
	fclose(fp);

}

int main() {
	int csock = socket(PF_INET, SOCK_STREAM, 0);
	if (csock == -1) {
		perror("socket()");
		return -1;
	}

	struct sockaddr_in saddr = {0, };
	saddr.sin_family = AF_INET;
	saddr.sin_addr.s_addr = inet_addr(ADDRMONITOR);
	saddr.sin_port = htons(5000);

	int ret = connect(csock, (struct sockaddr *)&saddr, sizeof saddr);
	if (ret == -1) {
		perror("connect");
		return -1;
	}
	printf("서버와의 접속이 성립되었습니다...\n");

	int i=0;
	char buf[128];
	
	while(1){

		getData(csock);
		sleep(1);

	}

	close(csock);
}


