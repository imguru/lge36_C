
#include <wiringPi.h>
#include <stdio.h>
#include "../motor/motor.h"
#include "../TRSensors/TRSensors.h"
#include "../obsIR/obstacle.h"

int maximum = 75;
int integral = 0;
int last_proportional = 0;
int sensors[NUMSENSOR];

int main(void) {
	wiringPiSetup();
	motor_init();
	TRSensor_init();
	int power=100;
	int position=0;	
	int proportional=0;
	int derivative = 0;
	int power_difference = 0;
	int motorSpeedL = 0;
	int motorSpeedR = 0;

	for(int i=0;i<100;i++){
		if(i<25 || i>=70){
			right();
			setPWMA(50);
			setPWMB(50);
		}
		else{
			left();
			setPWMA(50);
			setPWMB(50);
		}
		TRSensor_calibrate();
	}
	stop();

	forward();

	while(1){
		position = TRSensor_readLine(sensors,0);
		for(int i=0;i<NUMSENSOR;i++){
			printf("%d ",sensors[i]);
		}
		printf(" | %d \n", position);
		proportional = position - 2000;
		derivative = proportional - last_proportional;
		integral += proportional;
		last_proportional = proportional;

		power_difference = proportional/30 + integral/10000 + derivative*2;
		printf("%d \n", power_difference);
		if(power_difference > maximum){
			power_difference = maximum;
		}
		if(power_difference < -maximum){
			power_difference = -maximum;
		}
		if(power_difference < 0){
			motorSpeedL = maximum+power_difference;
			motorSpeedR = maximum;
		}
		else{
			motorSpeedL = maximum;
			motorSpeedR = maximum-power_difference;
		}
		setPWMA(motorSpeedL);
		setPWMB(motorSpeedR);
	}
	return 0;
}

