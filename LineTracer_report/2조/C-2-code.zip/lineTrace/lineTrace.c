#include <stdio.h>
#include "lineTrace.h"
#include "../motor/motor.h"
#include "../TRSensors/TRSensors.h"
#include <wiringPi.h>


int maximum = 80;
int integral = 0;
int last_proportional = 0;
int sensors[NUMSENSOR];
int position=0;
int motorSpeedL = 0;
int motorSpeedR = 0;
int power=100;
int proportional=0;
int derivative = 0;
int power_difference = 0;


void lineRescue(int rescue) {
	if (rescue) {
		stop();
	} else {
		forward();
	}
}

void getlineData(int *Sensor){
	for(int i=0;i<NUMSENSOR;i++){
		Sensor[i]=sensors[i];
	}
}

void line_init(void)
{
	wiringPiSetup();
	motor_init();
	TRSensor_init();
	for(int i=0;i<100;i++){
		if(i<25 || i>=70){
			right();
			setPWMA(15);
			setPWMB(15);
		}
		else{
			left();
			setPWMA(15);
			setPWMB(15);
		}
		TRSensor_calibrate();
	}
	stop();
	forward();
}

void lineTrace(void)
{
	line_init();
	while(1){
		position = TRSensor_readLine(sensors,0);//
		for(int i=0;i<NUMSENSOR;i++){
			printf("%d ",sensors[i]);
		}
		//	printf(" | %d \n", position);
		proportional = position - 2000;
		derivative = proportional - last_proportional;
		integral += proportional;
		last_proportional = proportional;

		power_difference = proportional/30 + integral/10000 + derivative*2;
		printf("%d \n", power_difference);
		if(power_difference > maximum){
			power_difference = maximum;
		}
		if(power_difference < -maximum){
			power_difference = -maximum;
		}
		if(power_difference < 0){
			motorSpeedL = maximum+power_difference;
			motorSpeedR = maximum;
		}
		else{
			motorSpeedL = maximum;
			motorSpeedR = maximum-power_difference;
		}
		setPWMA(motorSpeedL);
		setPWMB(motorSpeedR);
	}
}
