#ifndef _LINETRACE_H_
#define _LINETRACE_H_

#include "../motor/motor.h"
#include "../TRSensors/TRSensors.h"
//#include "../obsIR/obstacle.h"

/*
int maximum = 75;
int integral = 0;
int last_proportional = 0;
int sensors[NUMSENSOR];
int position=0;
int motorSpeedL = 0;
int motorSpeedR = 0;
int power=100;
int proportional=0;
int derivative = 0;
int power_difference = 0;
*/

void line_init(void);
void lineTrace(void);
void getlineData(int *Sensor);
void lineRescue(int rescue);
#endif

