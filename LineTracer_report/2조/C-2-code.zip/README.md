How to Compile
gcc -c motor/motor.c
gcc -c TRSensors/TRSensors.c
gcc -c lineTrace/lineTrace.c
gcc -c lineMaze/linemaze.c
gcc -c lineMaze/follow-segment.c
gcc -c server/server.c
gcc -c server/serverlib.c

gcc -o R_server TRSensors.o follow-segment.o lineTrace.o motor.o serverlib.o linemaze.o server.o -lwiringPi -pthread
