#ifndef _OBSTACLE_H_
#define _OBSTACLE_H_

#define ENA 22
#define ENB 25
#define obsR 27
#define obsL 24
#define BUZZ 7

int velRead(int port);
int obsRead(int port);
void buzz(int out);
void obs_init(void);
void obsDetection(void);

#endif
