#include <wiringPi.h>
#include <stdio.h>
#include "obstacle.h"
#include "../motor/motor.h"

int buzzFlag = 0;
int obsLL = 0;
int obsRR = 0;


int velRead(int port){
	return digitalRead(port);
}

int obsRead(int port){
	return digitalRead(port);
}

void buzz(int out){
	if(out == 1 || out == 0)
		digitalWrite(BUZZ, out);
}

void obs_init(void)
{
	pinMode(obsR, INPUT);
    pinMode(obsL, INPUT);
    pinMode(BUZZ, OUTPUT);
}

void obsDetection(void)
{
	obsLL = obsRead(obsL);
	obsRR = obsRead(obsR);
	if(!obsLL||!obsRR){
		buzzFlag = 1;
		buzz(buzzFlag);
		left();
		setPWMA(30);
		setPWMB(30);
		delay(300);
}
	buzzFlag = 0;
	buzz(buzzFlag);
	
}

int main(){
	motor_init();
	wiringPiSetup();
	obs_init();
	while(1){
	forward();
	setPWMA(20);
	setPWMB(20);
	obsDetection();
}
	return 0;
}
