#ifndef _MOTOR_H
#define _MOTOR_H
void motor_init( );
void forward();
void stop();
void backward();
void left();
void right();
void setPWMA(int value);
void setPWMB(int value);
void setMotor(int left, int right);

#endif
