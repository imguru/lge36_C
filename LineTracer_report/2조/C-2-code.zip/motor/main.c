#include "motor.h"
#include <stdio.h>
#include <wiringPi.h>
int main(){
	wiringPiSetup();
	motor_init();
	//while(1){
	//	forward();
	//	printf("%d %d\n",1,2);
	//}
	left();
	
	setPWMA(30);
	setPWMB(30);
	delay(280);	
stop();
	return 0;
}
