#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<wiringPi.h>
#include<softPwm.h>

#include"motor.h"

#define AIN1 26
#define AIN2 23
#define BIN1 28
#define BIN2 29
#define ENA 22
#define ENB 25

int PA = 50;
int PB = 50;

void motor_init(void) {
    pinMode(AIN1,OUTPUT);
    pinMode(AIN2,OUTPUT);
    pinMode(BIN1,OUTPUT);
    pinMode(BIN2,OUTPUT);
    pinMode(ENA,OUTPUT);
    pinMode(ENB,OUTPUT);
    softPwmCreate(ENA, 0,100);
    softPwmCreate(ENB, 0,100);
}

void forward(){
    digitalWrite(AIN1,0);
    digitalWrite(AIN2,1);
    digitalWrite(BIN1,0);
    digitalWrite(BIN2,1);
    softPwmWrite(ENA, PA);
    softPwmWrite(ENB, PB);
}

void stop(){
    softPwmWrite(ENA, 0);
    softPwmWrite(ENB, 0);
    digitalWrite(AIN1,0);
    digitalWrite(AIN2,0);
    digitalWrite(BIN1,0);
    digitalWrite(BIN2,0); 
}

void backward(){
    digitalWrite(AIN1,1);
    digitalWrite(AIN2,0);
    digitalWrite(BIN1,1);
    digitalWrite(BIN2,0);
    softPwmWrite(ENA, PA);
    softPwmWrite(ENB, PB);
}

void left(){
    digitalWrite(AIN1,1);
    digitalWrite(AIN2,0);
    digitalWrite(BIN1,0);
    digitalWrite(BIN2,1);
    softPwmWrite(ENA, 300);
    softPwmWrite(ENB, 300);
}

void right(){
    digitalWrite(AIN1,0);
    digitalWrite(AIN2,1);
    digitalWrite(BIN1,1);
    digitalWrite(BIN2,0);
    softPwmWrite(ENA, 300);
    softPwmWrite(ENB, 300);
}

void setPWMA(int value){
	PA = value;
	softPwmWrite(ENA, PA);
}

void setPWMB(int value){
	PB = value;
	softPwmWrite(ENB, PB);
}

void setMotor(int left, int right){
	if( (right >= 0) && (right <= 100) ){
		digitalWrite(AIN1, 1);
		digitalWrite(AIN2, 0);
		softPwmWrite(ENA, right);
	}
	else if( (right < 0) && (right >= -100) ){
		digitalWrite(AIN1, 0);
		digitalWrite(AIN2, 1);
		softPwmWrite(ENA, 0-right);
	}
	if( (left >= 0) && (left <=100)){
		digitalWrite(BIN1, 1);
		digitalWrite(BIN2, 0);
		softPwmWrite(ENB, left);
	}	
	else if( (left<0) && (left >= -100)){
		digitalWrite(BIN1, 0);
		digitalWrite(BIN2, 1);
		softPwmWrite(ENB, 0 - left);
	}
}

#if 0
void right_rotate_90(){
    for(int i=0;i<700;i++){
        right();
        usleep(500);
    }
}

void go_forward(){
    for(int i=0;i<500;i++){
	forward();
	usleep(500);
    }
}
int main(){
    wiringPiSetup();

    motor_init();
    go_forward();
    right_rotate_90();
    go_forward();   
    stop();
    return 0;
}
#endif
