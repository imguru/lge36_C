#ifndef __SERVERLIB_H_
#define __SERVERLIB_H_

struct packet {
    char *base;
    char *ptr;
};

void init_packet(struct packet *packet, char *buf);
void put_int32(struct packet *packet, int value);
void put_int16(struct packet *packet, short value);
int build_packet(struct packet *packet);

#endif
