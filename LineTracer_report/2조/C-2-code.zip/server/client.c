#include <sys/types.h>
#include <sys/socket.h>

#include <stdio.h>

#include "clientlib.h"

int main() {
    int csock = socket(PF_INET, SOCK_STREAM, 0);
    if (csock == -1) {
        perror("socket");
        return 1;
    }

    struct sockaddr_in saddr = {0, };
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    saddr.sin_port = htons(5000);

   if (connect(csock, (struct sockaddr *)&saddr, sizeof saddr) == -1) {
        perror("connect");
        return 1;
    }

    printf("server connection start...\n");
    char buf[64];
    int ret;
    int i = 0;
    struct packet packet;

    while (1) {
	char *p;
	short len;
	ret = readn(csock, buf, sizeof len);
	if (ret <= 0)
	    break;

	len = ntohs(*(short *)buf);
	ret = readn(csock, buf, len);
	if (ret <= 0) {
	    break;
	}

	init_packet_client(&packet, buf);
	
	int temp[5];
	for (i = 0; i < 5; i++) 
			temp[i] = get_int32(&packet);
	//int cds = get_int32(&packet);

	printf("%d - temp: %d %d %d %d %d\n", ++i, temp[0],temp[1],temp[2],temp[3],temp[4]);
    }

    close(csock);
    return 0;
}

