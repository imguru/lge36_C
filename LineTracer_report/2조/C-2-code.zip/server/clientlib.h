#ifndef __CLIENTLIB_H_
#define __CLIENTLIB_H_

#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>

struct packet {
    char *base;
    char *ptr;
    char *rptr;
};

void init_packet_client(struct packet *packet, char *buf);
int get_int32(struct packet *packet); 
short get_int16(struct packet *packet); 
ssize_t readn(int fd, void *vptr, size_t n);

#endif
