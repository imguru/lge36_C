#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>

#include <stdio.h>

#include "serverlib.h"
#include "../lineMaze/linemaze.h"
#include "../lineTrace/lineTrace.h"

int mode;
int rescue; 

int catchint(int signo) {

	if(!rescue) {
				
		printf("긴급멈춤 ..\n");
		rescue = 1;
		lineRescue(rescue);
	} else {
		printf("재시작 ..\n");
		rescue = 0;
		lineRescue(rescue);
	}

}

void *trans_thread(void *arg) {

		struct packet packet;
        int ret;
        char buf[64];
        int i = 0;
		int len;
		int csock = (intptr_t)arg;
		
		while (1) {
			// mv global
			int sensor[5];

			init_packet(&packet, buf);

			if (!mode) {
				getMazeData(sensor);
			} else {
				getlineData(sensor);
			}			
			
			for (i = 0; i < 5; i++){ 
				//printf("!!@#$ %d",sensor[i]);
				put_int32(&packet, sensor[i]);
			}
			
			//delay(50);
			//put_int32(&packet, cds);

			len = build_packet(&packet);
			if (write(csock, packet.base, len) == -1) {
				perror("write");
				break;
			}

		}

		close(csock);
		printf(" the end of connection..\n");

}



void *comm_thread(void *arg) {

	int ssock;

    ssock = socket(PF_INET, SOCK_STREAM, 0);

	if (ssock == -1) {
		perror("socket");
		//return 1;
	}

    int option = 1;
    setsockopt(ssock, SOL_SOCKET, SO_REUSEADDR, &option, sizeof option);

    struct sockaddr_in saddr = {0, };
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(5000);
 
    if (bind(ssock, (struct sockaddr *)&saddr, sizeof saddr) == -1) {
        perror("bind");
        //return 1;
    }

    if (listen(ssock, SOMAXCONN) == -1) {
        perror("listen");
        //return 1;
    }

    while (1) {
        struct sockaddr_in caddr = {0, };
        socklen_t caddrlen = sizeof caddr;
        int csock = accept(ssock, (struct sockaddr *)&caddr, &caddrlen);
        if (csock == -1) {
            perror("accept");
           // return 1;
        }
	
		printf("client: %s\n", inet_ntoa(caddr.sin_addr));


	// mv thread
		pthread_t trans_thread_id;

		intptr_t arg = csock;
		pthread_create(&trans_thread_id, NULL, trans_thread, (void *) arg);
		pthread_detach(trans_thread_id);

		


	}

	close(ssock);
}




int main() {
	
	pthread_t comm_thread_id;

	pthread_create(&comm_thread_id, NULL, comm_thread, NULL);
	pthread_detach(comm_thread_id);
	
	signal(SIGINT,(void *) catchint);

	while(1) {
		//int mode;

		printf("maze or line ? \n");

		scanf("%d",&mode);
		
		if(!mode) {
			printf("start solve maze!\n");
			solve_maze();
		} else {
			printf("start line trace!\n");
			lineTrace();
		}
		mode = 0;
	}


	return 0;
}
