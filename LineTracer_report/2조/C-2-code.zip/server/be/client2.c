#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include <stdio.h>

struct packet {
    char *base;
    char *ptr;
    char *rptr;
};

void init_packet(struct packet *packet, char *buf) {
    packet->base = buf;
    packet->rptr = buf;

    packet->ptr = buf + sizeof(short);
}

int get_int32(struct packet *packet) {
    int ret = *(int *)packet->rptr;
    packet->rptr += sizeof(int);
    return ntohl(ret);
}


short get_int16(struct packet *packet) {
    short ret = *(short *)packet->rptr;
    packet->rptr += sizeof(short);
    return ntohs(ret);
}

ssize_t readn(int fd, void *vptr, size_t n)
{
    size_t  nleft;
    ssize_t nread;
    char    *ptr;

    ptr = vptr;
    nleft = n;
    while (nleft > 0) {
        if ( (nread = read(fd, ptr, nleft)) < 0) {
            if (errno == EINTR)
                nread = 0;
            else
                return(-1);
        } else if (nread == 0)
            break;

        nleft -= nread;
        ptr   += nread;
    }
    return(n - nleft);      /* return >= 0 */
}

int main() {
    int csock = socket(PF_INET, SOCK_STREAM, 0);
    if (csock == -1) {
        perror("socket");
        return 1;
    }

    struct sockaddr_in saddr = {0, };
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    saddr.sin_port = htons(5000);

   if (connect(csock, (struct sockaddr *)&saddr, sizeof saddr) == -1) {
        perror("connect");
        return 1;
    }

    printf("server connection start...\n");
    char buf[64];
    int ret;
    int i = 0;
    struct packet packet;

    while (1) {
	char *p;
	short len;
	ret = readn(csock, buf, sizeof len);
	if (ret <= 0)
	    break;

	len = ntohs(*(short *)buf);
	ret = readn(csock, buf, len);
	if (ret <= 0) {
	    break;
	}

	init_packet(&packet, buf);
	int temp = get_int32(&packet);
	//int cds = get_int32(&packet);

	printf("%d - temp: %d\n", ++i, temp);
    }

    close(csock);
    return 0;
}

