#include "clientlib.h"

void init_packet_client(struct packet *packet, char *buf) {
    packet->base = buf;
    packet->rptr = buf;

    packet->ptr = buf + sizeof(short);
}

int get_int32(struct packet *packet) {
    int ret = *(int *)packet->rptr;
    packet->rptr += sizeof(int);
    return ntohl(ret);
}


short get_int16(struct packet *packet) {
    short ret = *(short *)packet->rptr;
    packet->rptr += sizeof(short);
    return ntohs(ret);
}

ssize_t readn(int fd, void *vptr, size_t n)
{
    size_t  nleft;
    ssize_t nread;
    char    *ptr;

    ptr = vptr;
    nleft = n;
    while (nleft > 0) {
        if ( (nread = read(fd, ptr, nleft)) < 0) {
            if (errno == EINTR)
                nread = 0;
            else
                return(-1);
        } else if (nread == 0)
            break;

        nleft -= nread;
        ptr   += nread;
    }
    return(n - nleft);      /* return >= 0 */
}

