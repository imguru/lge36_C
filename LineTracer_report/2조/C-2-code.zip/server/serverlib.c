#include "serverlib.h"
#include <arpa/inet.h>

void init_packet(struct packet *packet, char *buf) {
    packet->base = buf;
    packet->ptr = buf + sizeof(short);
}

void put_int32(struct packet *packet, int value) {
    *(int *)packet->ptr = htonl(value);
    packet->ptr += sizeof(int);
}

void put_int16(struct packet *packet, short value) {
    *(short *)packet->ptr = htons(value);
    packet->ptr += sizeof(short);
}

int build_packet(struct packet *packet) {
    short ret = packet->ptr - packet->base;
    *(short *)packet->base = htons(ret);

    return ret + sizeof(short);
}

