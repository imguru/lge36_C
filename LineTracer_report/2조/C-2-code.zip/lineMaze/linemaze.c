#include <wiringPi.h>
#include <stdio.h>
#include "follow-segment.h"
#include "linemaze.h"


int sensors[NUMSENSOR];
int position;

void getMazeData(int *Sensor){
	for(int i=0; i<NUMSENSOR; i++){
		Sensor[i] = sensors[i];
	}
}

char select_turn(unsigned char found_left, unsigned char found_straight, unsigned char found_right,unsigned char found_back)
{

	if(found_left)
		return 'L';
	else if(found_straight)
		return 'S';
	else if(found_right)
		return 'R';
	else if(found_back);
	return 'B';
	return 0;
}

void turn(char dir)
{
	int temp[NUMSENSOR];
	switch(dir)
	{
		case 'L':
			left();
			setPWMA(20);
			setPWMB(20);
			delay(350);
			forward();
			setPWMA(SPEED);
			setPWMA(SPEED);
			delay(50);
			break;
		case 'R':
			right();
			setPWMA(20);
			setPWMB(20);
			delay(300);
			forward();
			setPWMA(SPEED);
			setPWMA(SPEED);
			delay(50);
			break;
		case 'B':
			stop();
			backward();
			setPWMA(20);
			setPWMB(20);
			delay(80);
			TRSensor_readLine(temp,0);
			if(temp[4] >300){
			}
			else{
				right();
				setPWMA(20);
				setPWMB(20);
				delay(800);
				forward();
				setPWMA(SPEED);
				setPWMA(SPEED);
				delay(50);
			}
			break;
		case 'S':
			right();
			setPWMA(20);
			setPWMB(20);
			delay(30);
			forward();
			delay(20);
			break;
	}
}

void maze_init(void)
{
	for(int i=0;i<100;i++){
		if(i<25 || i>=75){
			right();
			setPWMA(10);
			setPWMB(10);
		}
		else{
			left();
			setPWMA(10);
			setPWMB(10);
		}
		TRSensor_calibrate();
	}
	stop();
	forward();
	delay(100);
}


void solve_maze(void) 
{
	int i=0;
	wiringPiSetup();
	motor_init();
	TRSensor_init();
	maze_init();
	while(1) {
		//forward();
		int found_left = 0;
		int found_straight = 0;
		int found_right = 0;
		int found_back = 0;
		follow_segment();
		stop();
		position = TRSensor_readLine(sensors, 0);
		for (i = 0; i < NUMSENSOR; i++) {
			printf("%d ", sensors[i]);
		}
		printf(" | %d \n", position);

		if (sensors[0] > 300)
			found_left = 1;
		if (sensors[4] > 300)
			found_right = 1;

		if (sensors[1] > 200 || sensors[2] > 200 || sensors[3] > 200)
			found_straight = 1;
		if (sensors[0] <10 && sensors[1] <10 && sensors[2] <10 && sensors[3] <10 && sensors[4] <10){
			found_back = 1;
		}

		char dir = select_turn(found_left, found_straight, found_right, found_back);

		printf("path : %c\n ",dir);

		turn(dir);
	}
	stop();
}
