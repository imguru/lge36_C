
#include <wiringPi.h>
#include <stdio.h>
#include "follow-segment.h"

void follow_segment()
{
	int last_proportional = 0;
	int i;
	long integral=0;
	const int max = 30;
/*	
	for(int i=0;i<100;i++){
		if(i<25 || i>=70){
			right();
			setPWMA(50);
			setPWMB(50);
		}
		else{
			left();
			setPWMA(50);
			setPWMB(50);
		}
		TRSensor_calibrate();
	}
	stop();

	forward();
*/
	while(1)
	{
		
		int sensors[5];
		int position = TRSensor_readLine(sensors,0);
		/*	
		for (i = 0; i < NUMSENSOR; i++) {
			printf("follow : %d ", sensors[i]);
		}  
		printf(" | %d \n", position);
		*/
		int proportional = ((int)position) - 2000;

		
		int derivative = proportional - last_proportional;
		integral += proportional;

		
		last_proportional = proportional;

		
		int power_difference = proportional/30 + integral/10000 + derivative*2;
		//power_difference /= 2;	
		if(power_difference > max)
			power_difference = max;
		if(power_difference < -max)
			power_difference = -max;
		
		if(power_difference < 0) {
			setPWMA(max+power_difference);
            setPWMB(max);
		}     
        else{
            setPWMA(max);
            setPWMB(max - power_difference);
        }
		
		if(sensors[1] < 100 && sensors[2] < 100 && sensors[3] < 100)
		{
			
			return;
		}
		else if(sensors[0] > 300 || sensors[4] > 300)
		{
			
			return;
		}
		//delay(1);

	}
}


