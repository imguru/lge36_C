#ifndef __LINEMAZE_H_
#define __LINEMAZE_H_

#define SPEED 25


void getMazeData(int *Sensor);
char select_turn(unsigned char found_left, unsigned char found_straight, unsigned char found_right,unsigned char found_back);
void turn(char dir);
void maze_init(void);
void solve_maze(void);

#endif

