#ifndef __FOLLOW_SEGMENT_H__
#define __FOLLOW_SEGMENT_H__

#include "../motor/motor.h"
#include "../TRSensors/TRSensors.h"

void follow_segment();

#endif
