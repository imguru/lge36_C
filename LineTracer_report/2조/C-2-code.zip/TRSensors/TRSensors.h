#ifndef _TRSENSOR_H_
#define _TRSENSOR_H_
#define CS 21
#define CLOCK 6 
#define ADDRESS 5
#define DATAOUT 4 
#define NUMSENSOR 5
int calibratedMin[NUMSENSOR];
int calibratedMax[NUMSENSOR];
int last_value;
void TRSensor_init(void);
int TRSensor_AnalogRead(int value[]);
int TRSensor_calibrate(void);
int TRSensor_readCalibrated(int sensor_values[]);
int TRSensor_readLine(int sensor_values[], int white_line);
#endif
