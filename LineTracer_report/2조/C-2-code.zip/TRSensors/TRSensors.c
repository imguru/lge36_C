#include <string.h>
#include <stdio.h>
#include <wiringPi.h>
#include <unistd.h>
#include "TRSensors.h"
void TRSensor_init(void)
{
	pinMode(CLOCK, OUTPUT);
	pinMode(ADDRESS, OUTPUT);
	pinMode(CS, OUTPUT);
	pinMode(DATAOUT, INPUT);
	pullUpDnControl(DATAOUT, PUD_UP);
	
	memset(calibratedMin, 0, sizeof(calibratedMin));
	memset(calibratedMax, 1023, sizeof(calibratedMax));
	last_value = 0;
	return;
}
int TRSensor_AnalogRead(int *value)
{
	int temp_value[NUMSENSOR+1] = {0, };
	for(int j=0; j<NUMSENSOR+1; j++)
	{
		digitalWrite(CS, LOW);
		for(int i=0; i<4; i++)
		{
			//sent 4-bit Address
			if((j>>(3-i)) & 0x01)
				digitalWrite(ADDRESS, HIGH);
			else
				digitalWrite(ADDRESS, LOW);
			delayMicroseconds(1);
			// read MSB 4-bit data
			temp_value[j] <<= 1;
			if(digitalRead(DATAOUT))
				temp_value[j] |= 0x01;
			digitalWrite(CLOCK, HIGH);
			delayMicroseconds(3);
			digitalWrite(CLOCK, LOW);
		}
		for(int i=0; i<6; i++)
		{
			temp_value[j] <<= 1;
			if(digitalRead(DATAOUT))
				temp_value[j] |= 0x01;
			digitalWrite(CLOCK, HIGH);
			delayMicroseconds(3);
			digitalWrite(CLOCK, LOW);
		}
		delay(1);
		digitalWrite(CS, HIGH);
	}
	for(int i=1; i<NUMSENSOR+1; i++)
		value[i-1] = temp_value[i];
	return 0;
}
int TRSensor_calibrate(void)
{
	int max_sensor_values[NUMSENSOR] = {0, };
	int min_sensor_values[NUMSENSOR] = {0, };
	
	for(int j=0; j<10; j++)
	{
		int sensor_values[NUMSENSOR] = {0, };
		TRSensor_AnalogRead(sensor_values);
		for(int i=0; i<NUMSENSOR; i++)
		{
			// set the max we found THIS time
			if((j==0) || (max_sensor_values[i] < sensor_values[i]))
				max_sensor_values[i] = sensor_values[i];
			// set the min we found THIS time
			if((j==0) || (min_sensor_values[i] > sensor_values[i]))
				min_sensor_values[i] = sensor_values[i];
		}
	}
	// record the min and max calibration values
	for(int i=0; i<NUMSENSOR; i++)
	{
		if(min_sensor_values[i] > calibratedMin[i])
			calibratedMin[i] = min_sensor_values[i];
		if(max_sensor_values[i] < calibratedMax[i])
			calibratedMax[i] = max_sensor_values[i];
	}
	return 0;
}
int TRSensor_readCalibrated(int sensor_values[])
{
	double value = 0;
	double denominator = 0;
	TRSensor_AnalogRead(sensor_values);
	for(int i=0; i<NUMSENSOR; i++)
	{
		denominator = calibratedMax[i] - calibratedMin[i];
		if(denominator != 0)
			value = (sensor_values[i] - calibratedMin[i]) * 1000. / denominator;
		if(value < 0)
			value = 0;
		else if(value > 1000)
			value = 1000;
		sensor_values[i] = (int)value;
	}
	return 0;
}
int TRSensor_readLine(int sensor_values[], int white_line)
{
	double avg = 0;
	double sum = 0;
	int on_line = 0;
	TRSensor_readCalibrated(sensor_values);
	
	for(int i=0; i<NUMSENSOR; i++)
	{
		int value = sensor_values[i];
		if(white_line)
			value = 1000 - value;
		//keep track of wheter we see the line at all
		if(value > 200)
			on_line = 1;
		if(value > 50)
		{
			avg += value * (i * 1000);	// this is for the weighted total,
			sum += value;				// this is for the denominator
		}
	}
	if(on_line != 1)
	{
		// IF it last read to the left of center, return 0
		if(last_value < (NUMSENSOR - 1)*1000/2)
		{
			last_value = 0;
		}
		// IF it last read to the right of center, return max
		else
		{
			last_value = (NUMSENSOR - 1) * 1000;
		}
	}
	else
		last_value = avg/sum;
	return last_value;
}
