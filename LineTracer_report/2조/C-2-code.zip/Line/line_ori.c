#include <wiringPi.h>
#include <stdio.h>
#include "../motor/motor.h"
#include "../TRSensors/TRSensors.h"

int maximum = 60;
int integral = 0;
int last_proportional = 0;
int sensors[NUMSENSORS];

int main(void) {
	wiringPiSetup();
	motor_init();
	TR_init();
	int power=100;
	int position=0;	
	int proportional=0;
	int derivative = 0;
	int power_difference = 0;
	
	for(int i=0;i<100;i++){
		if(i<25 || i>= 70){
			right();
			setPWMA(30);
			setPWMB(30);
		}
		else{
			left();
			setPWMA(30);
			setPWMB(30);
		}
		TRCal();
	}
	//TRCal();
	stop();
	
	forward();
	
	while(1){
		position = readLine(0,sensors);
		for(int i=0;i<NUMSENSORS;i++){
			printf("%d ",sensors[i]);
		}
		printf(" | %d \n", position);
		//if( sensors[0] > 900 && sensors[1] > 900 && sensors[2] > 900 && sensors[3] > 900 && sensors[4] > 900){
		//	setPWMA(0);
		//	setPWMB(0);
		//}
		//else{
		proportional = position - 2000;
		derivative = proportional - last_proportional;
		integral += proportional;
		last_proportional = proportional;

		//power_difference = proportional/30 + integral/10000 + derivative*2;
		power_difference = proportional/20 + integral/10000 + derivative*3/2;

		if(power_difference > power){
			power_difference = power;
			//maximum = 50;
		}
		else if(power_difference < -power){
			power_difference = -power;
			//maximum =50;
		}
		power_difference *= 0.5;
		printf("%d \n", power_difference);
		if(power_difference > maximum){
			power_difference = maximum;
		}
		if(power_difference < -maximum){
			power_difference = -maximum;
		}
		if(power_difference < 0){
			setPWMA(maximum + power_difference);
			setPWMB(maximum);
		}
		else{
			setPWMA(maximum);
			setPWMB(maximum - power_difference);
		}
		//maximum = 70;
		//}
		delay(30);
	}

	return 0;
}

