#include <wiringPi.h>
#include <stdio.h>
#include "../motor/motor.h"
#include "../TRSensors/TRSensors.h"

int curve = 75;
int line = 90;
int maximum =80;
int R = 0;
int L = 0;
int integral = 0;
int last_proportional = 0;
int sensors[NUMSENSOR];

void getLineData(int *Sensor){
	for(int i=0;i<NUMSENSOR;i++){
		Sensor[i] = sensors[i];
	}
}

int main(void) {
	wiringPiSetup();
	motor_init();
	TRSensor_init();
	int power=80;
	int position=0;	
	int proportional=0;
	int derivative = 0;
	int power_difference = 0;
	
	for(int i=0;i<100;i++){
		if(i<25 || i>= 75){
			right();
			setPWMA(10);
			setPWMB(10);
		}
		else{
			left();
			setPWMA(10);
			setPWMB(10);
		}
		TRSensor_calibrate();
	}
	//TRCal();
	stop();
	
	forward();
	
	while(1){
		position = TRSensor_readLine(sensors,0);
		/*
		for(int i=0;i<NUMSENSOR;i++){
			printf("%d ",sensors[i]);
		}
		printf(" | %d \n", position);
		*/
		//if( sensors[0] > 900 && sensors[1] > 900 && sensors[2] > 900 && sensors[3] > 900 && sensors[4] > 900){
		//	setPWMA(0);
		//	setPWMB(0);
		//}
		//else{
		if(sensors[0] > 300){
			L += 1;
			L = L%2;
			//position = 2000;
		}
		if(sensors[4] > 300){
			R += 1;
			R = R%2;
			//position = 2000;
		}
		if(L || R){
			maximum = curve;
		}
		else{
			maximum = line;
		}

		printf("%d\n",position);
		proportional = position - 2000;
		derivative = proportional - last_proportional;
		integral += proportional;
		last_proportional = proportional;

	//	power_difference = proportional/30 + integral/10000 + derivative*2;
		power_difference = proportional/20 + integral/10000 + derivative*3/2;

		if(power_difference > power){
			power_difference = power;
			//maximum = 50;
		}
		else if(power_difference < -power){
			power_difference = -power;
			//maximum =50;
		}
		if(L || R){
			maximum = curve;
}
		else{
			maximum = line;
}
		//power_difference *= 0.5;
		//printf("%d \n", power_difference);
		//power_difference *= 0.4;
		if(power_difference > maximum){
			power_difference = maximum;
		}
		if(power_difference < -maximum){
			power_difference = -maximum;
		}
		if(power_difference < 0){
			setPWMA(maximum + power_difference);
			setPWMB(maximum);
		}
		else{
			setPWMA(maximum);
			setPWMB(maximum - power_difference);
		}
		//maximum = 70;
		//}
		//delay(10);
		delayMicroseconds(10);
	}
	return 0;
}

