#include "linefollow.h"
#include "Infrared_Obstacle.h"

void infrared_init(){
	wiringPiSetup();
	pinMode(DR, INPUT);
	pinMode(DL, INPUT);
	pinMode(SPKR, OUTPUT);
}

void sound(){

	digitalWrite(SPKR, 1);
	usleep(100000);
	digitalWrite(SPKR, 0);
}

void speed_value(int left, int right){
	setPWMA(left);
	setPWMB(right);
}

void obstacle_status(){
	int i=0;
	int DL_status;
	int DR_status;

	DR_status=digitalRead(DR);
	DL_status=digitalRead(DL);
	
	if(DL_status==0){
		sound();
		speed_value(0,0);
		sleep(0.5);
		Left();
		speed_value(25,15);
		sleep(0.5);
	}else if(DR_status==0){
		sound();
		speed_value(0,0);
		sleep(0.5);
		Right();
		speed_value(15,25);
		sleep(0.5);
	}else{
		speed_value(15,15);
		Forward();
	}
	
}

int main(void){
	infrared_init();
	Al_init();

	while(1){
		obstacle_status();
		usleep(100000);
	}
	return 0;
}
