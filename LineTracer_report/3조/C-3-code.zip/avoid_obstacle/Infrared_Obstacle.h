#ifndef INFRARED
#define	INFRARED

#define	DL		24
#define DR		27
#define SPKR	7

void infrared_init();
void sound();
void obstacle_status();
void speed_value(int left, int right);

#endif
