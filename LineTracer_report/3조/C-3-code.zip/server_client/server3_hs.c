#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#include "linefollow.h"

struct packet{
	char *base;
	char *ptr;
};

void init_packet(struct packet *packet, char *buf) {
	packet->base = buf;
	packet->ptr = buf + sizeof(short);
}

void put_int32(struct packet *packet, int value) {
	*(int *)packet->ptr = htonl(value);
	packet->ptr += sizeof(int);
}

void put_int16(struct packet *packet, short value) {
	*(short *)packet->ptr = htons(value);
	packet->ptr += sizeof(short);
}

int build_packet(struct packet *packet) {
	short ret = packet->ptr - packet->base;
	*(short *)packet->base = htons(ret);

	return ret + sizeof(short);
}

void *Line_Follow_handler(void *arg) {
	LineFollow();
	return 0;
}

int main(void){
	int csock=socket(PF_INET, SOCK_STREAM, 0);
	if(csock==-1){
		perror("socket()");
		return -1;
	}

	struct sockaddr_in saddr={0,};
	saddr.sin_family=AF_INET;
	saddr.sin_addr.s_addr=inet_addr("192.168.0.153");
	saddr.sin_port=htons(5000);

	if(connect(csock, (struct sockaddr *)&saddr, sizeof saddr)==-1){
		perror("connect");
		return -1;
	}

	wiringPiSetup();
	printf("connect success!\n");
	char buf[128];
	int ret;

	int i = 1; 
	int j;
	int flag = 0;
	short len;
	struct packet packet;
	
	pthread_t line_thread;
	pthread_create(&line_thread, NULL, Line_Follow_handler, NULL);
	pthread_detach(line_thread);

	while(1){

		if((i%1000000) == 0) {
			init_packet(&packet, buf);
			put_int32(&packet, PA);
			put_int32(&packet, PB);

			len=build_packet(&packet);
			write(csock, packet.base, len);
			i = 1;
		}
		i++;
		
	}

	close(csock);
	return 0;
}
