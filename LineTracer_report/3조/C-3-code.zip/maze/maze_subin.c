#include "linefollow.h"


void speed_rate(int left, int right){
	setPWMA(left);
	setPWMB(right);
}

int main(){
	int flag;
	int position;
	values sensors;
	
	wiringPiSetup();
	//Al_init();
	TR_init();
	Al_init();

	flag=0;

	while(1){
		sensors=readLine(&position);
		
		if(sensors.s_value[0]<400 && sensors.s_value[1]<400){
			printf("LLLLLL\n");
			Left();
			speed_rate(10, 10);
			sleep(0.08);
		}
		else if(sensors.s_value[0]>700 && sensors.s_value[1]>700 && sensors.s_value[2]>700 && sensors.s_value[4]>700){
			printf("BBBBBB\n");
			Forward();
			speed_rate(10, 10);
			sleep(0.35);
			Right();
			//speed_rate(10, 10);
			sleep(0.6);
		}
		else{
			Forward();
			if(sensors.s_value[0]>600 && sensors.s_value[2]<400){
				Right();
				speed_rate(10, 10);
				sleep(0.02);
				Forward();
				speed_rate(10, 10);
				sleep(0.02);
			}
		}
	}

	return 0;
}
