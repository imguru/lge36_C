#include "alphabot2.h"

void Al_init() {

	pinMode(Left_F, OUTPUT);
	pinMode(Left_B, OUTPUT);
	pinMode(Right_F, OUTPUT);
	pinMode(Right_B, OUTPUT);

	pinMode(Left_Speed, PWM_OUTPUT);
	pinMode(Right_Speed, PWM_OUTPUT);

	softPwmCreate(Left_Speed, 0, 80);
	softPwmCreate(Right_Speed, 0, 80);

	PA = 40;
	PB = 40;
}

void Forward() {

	digitalWrite(Left_F, 1);
	digitalWrite(Left_B, 0);
	digitalWrite(Right_F, 1);
	digitalWrite(Right_B, 0);

	softPwmWrite(Left_Speed, PA);
	softPwmWrite(Right_Speed, PB);
}

void Stop() {
	softPwmWrite(Left_Speed, 0);
	softPwmWrite(Right_Speed, 0);

	digitalWrite(Left_F, 0);
	digitalWrite(Left_B, 0);
	digitalWrite(Right_F, 0);
	digitalWrite(Right_B, 0);
}

void Backward() {
	digitalWrite(Left_F, 0);
	digitalWrite(Left_B, 1);
	digitalWrite(Right_F, 0);
	digitalWrite(Left_B, 1);

	softPwmWrite(Left_Speed, PA);
	softPwmWrite(Right_Speed, PB);
}

void Left() {
	digitalWrite(Left_F, 0);
	digitalWrite(Left_B, 1);
	digitalWrite(Right_F, 1);
	digitalWrite(Right_B, 0);

	softPwmWrite(Left_Speed, 240);
	softPwmWrite(Right_Speed, 240);
}

void Right() {
	digitalWrite(Left_F, 1);
	digitalWrite(Left_B, 0);
	digitalWrite(Right_F, 0);
	digitalWrite(Right_B, 1);

	softPwmWrite(Left_Speed, 240);
	softPwmWrite(Right_Speed, 240);
}

void setPWMA(int value) {
	PA = value;
	softPwmWrite(Left_Speed, PA);
}

void setPWMB(int value) {
	PB = value;
	softPwmWrite(Right_Speed, PB);
}
#if 0
int main() {
	Al_init();
	while(1) {
		Forward();
	}
	return 0;
}
#endif
