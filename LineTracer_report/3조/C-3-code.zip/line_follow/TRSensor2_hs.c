#include "trsensor.h"

void TR_init() {
	int i;
	numSensors = 5;
	last_value = 0;

	for(i = 0; i < numSensors; i++) {
		calibratedMin[i] = 0;
		calibratedMax[i] = 1023;
	}

	pinMode(Clock, OUTPUT);
	pinMode(Address, OUTPUT);
	pinMode(CS, OUTPUT);
	pinMode(DataOut, INPUT);
	pinMode(Button, INPUT);
}

values AnalogRead() {
	int value[6] = {0, };

	int i,j;
	for(j = 0; j < (numSensors + 1); j++) {
		digitalWrite(CS, LOW);
		for(i = 0; i < 4; i++) {
			if((j >> (3 - i)) & 0x01) {
				digitalWrite(Address, HIGH);
			}
			else{
				digitalWrite(Address, LOW);
			}
			delayMicroseconds(1);
			value[j] <<= 1;
			if(digitalRead(DataOut)) {
				value[j] |= 0x01;
			}
			digitalWrite(Clock, HIGH);
			delayMicroseconds(3);
			digitalWrite(Clock, LOW);
		}

		for(i = 0; i < 6; i++) {
			value[j] <<= 1;
			if(digitalRead(DataOut)) {
				value[j] |= 0x01;
			}
			digitalWrite(Clock, HIGH);
			delayMicroseconds(3);
			digitalWrite(Clock, LOW);
		}
		delay(1);
		digitalWrite(CS, HIGH);
	}

	values sensors;

	for(i = 1; i < (numSensors + 1); i++) {
		sensors.s_value[i-1] = value[i];
	}

	return sensors;
}

void calibrate() {
	int max_sensor_values[5] = {0, };
	int min_sensor_values[5] = {0, };
	int i,j;
	values sensors;

	for(j = 0; j < 10; j++) {
		sensors = AnalogRead();
		for(i = 0; i < numSensors; i++) {
			if((j == 0) || (max_sensor_values[i] < sensors.s_value[i])){
				max_sensor_values[i] = sensors.s_value[i];
			}

			if((j == 0) || (min_sensor_values[i] > sensors.s_value[i])){
				min_sensor_values[i] = sensors.s_value[i];
			}
		}
	}

	for(i = 0; i < numSensors; i++) {
		if(min_sensor_values[i] > calibratedMin[i]) {
			calibratedMin[i] = min_sensor_values[i];
		}
		if(max_sensor_values[i] < calibratedMax[i]) {
			calibratedMax[i] = max_sensor_values[i];
		}
	}
}

values readCalibrated() {
	int i;
	int value = 0;
	int denominator;
	values sensors;

	sensors = AnalogRead();

	for(i = 0; i < numSensors; i++) {
		denominator = calibratedMax[i] - calibratedMin[i];

		if(denominator != 0) {
			value = ((sensors.s_value[i] - calibratedMin[i]) * 1000) / denominator;
		}

		if(value < 0 ) {
			value = 0;
		}
		else if(value > 1000) {
			value = 1000;
		}

		sensors.s_value[i] = value;
	}
	
	return sensors;
}

values readLine(int *position) {
	values sensors = readCalibrated();
	
	int avg = 0;
	int sum = 0;
	int on_line = 0;
	int white_line = 0;
	int i;
	int value;

	for(i = 0; i < numSensors; i++) {
		value = sensors.s_value[i];
		if(white_line) {
			value = 1000 - value;
		}
		if(value > 200) {
			on_line = 1;
		}
		if(value > 50) {
			avg += value * (i * 1000);
			sum += value;
		}
	}

	if(on_line != 1) {
		if(last_value < ((numSensors - 1)*1000/2)) {
			last_value = 0;
		}
		else {
			last_value = (numSensors - 1)*1000;
		}
	}
	else{
		last_value = avg/sum;
	}

	*position = last_value;

	return sensors;
}

/*int main() {
	wiringPiSetup();
	TR_init();
	int position;
	values sensors;

	while(1) {
		//sensors = AnalogRead();
		sensors = readLine(&position);
		printf("%d %d %d %d %d\n",sensors.s_value[0], sensors.s_value[1], sensors.s_value[2], sensors.s_value[3], sensors.s_value[4]);
		//usleep(200000);
	}
	return 0;
}*/
