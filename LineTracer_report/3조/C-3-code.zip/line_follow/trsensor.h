#ifndef TRSENSOR
#define TRSENSOR

#include "total.h"

#define CS 21
#define Clock 6
#define Address 5
#define DataOut 4
#define Button 11

int numSensors;
int calibratedMin[5];
int calibratedMax[5];
int last_value;

typedef struct _values{
	        int s_value[5];
}values;

void TR_init(void);
values AnalogRead(void);
void calibrate(void);
values readCalibrated(void);
values readLine(int *position);

#endif

