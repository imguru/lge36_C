#ifndef TOTAL
#define TOTAL

#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <unistd.h>
#include <softPwm.h>
#include <time.h>
#include <string.h>

#endif

