#ifndef LINEFOLLOW
#define LINEFOLLOW

#include "total.h"
#include "trsensor.h"
#include "alphabot2.h"

void LineFollow(void);

#endif
