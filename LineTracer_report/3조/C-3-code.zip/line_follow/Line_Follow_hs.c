#include "linefollow.h"

int main(void){
	int i,j;
	int integral = 0;
	int last_proportional = 0;
	int position;
	int proportional;
	int derivative;
	int power_difference;
	int maximum = 80;
	values sensors;
	
	int res;
	res = wiringPiSetup();
	if(res == -1) {
		exit(1);
	}

	TR_init();
	Al_init();
	printf("Line Follow Example\n");
	usleep(500000);

	for(i = 0; i < 100; i++) {
		if((i < 25) || (i >= 75)) {
			Right();
			setPWMA(16);
			setPWMB(16);
		}
		else{
			Left();
			setPWMA(16);
			setPWMB(16);
		}
		calibrate();
		printf("i = %d\n",i);
		printf("calibratedmin\n");
		printf("%d %d %d %d %d\n", calibratedMin[0], calibratedMin[1], calibratedMin[2], calibratedMin[3], calibratedMin[4]);
		printf("calibratedMax\n");
		printf("%d %d %d %d %d\n", calibratedMax[0], calibratedMax[1], calibratedMax[2], calibratedMax[3], calibratedMax[4]);
		
	}	

	Stop();
	
	Forward();

	while(1) {
		//sensors = AnalogRead();
		//position = last_value;
		//position = readLine();
		sensors = readLine(&position);
		printf("%d, %d, %d, %d, %d\n", sensors.s_value[0], sensors.s_value[1], sensors.s_value[2], sensors.s_value[3], sensors.s_value[4]);

		if((sensors.s_value[0] > 800) && (sensors.s_value[1] > 800) && (sensors.s_value[2] > 800) && (sensors.s_value[3] > 800) && (sensors.s_value[4] > 800)) {
			setPWMA(0);
			setPWMB(0);
		}
		else if((sensors.s_value[0] > 800) && (sensors.s_value[4] > 800) && (sensors.s_value[2] <= 700)) {
			setPWMA(100);
			setPWMB(100);
		}
		else
		{
			proportional = position - 2000;
			
			derivative = proportional - last_proportional;
			integral += proportional;

			last_proportional = proportional;

			power_difference = proportional/20 + integral/100000 + derivative*2;
			
			if(power_difference > maximum) {
				power_difference = maximum;
			}
			if(power_difference < -maximum) {
				power_difference = -maximum;
			}

			printf("position = %d, power difference = %d\n", position, power_difference);

			if(power_difference < 0) {
				setPWMA((maximum + power_difference));
				setPWMB(maximum);
			}
			else {
				setPWMA(maximum);
				setPWMB((maximum - power_difference));
			}
		}
	}
	return 0;
}
