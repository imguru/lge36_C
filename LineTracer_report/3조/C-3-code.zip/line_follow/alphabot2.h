#ifndef ALPHABOT2
#define ALPHABOT2

#include "total.h"

#define Left_F 23
#define Left_B 26
#define Right_F 29
#define Right_B 28
#define Left_Speed 22
#define Right_Speed 25

int PA;
int PB;
void Al_init(void);
void Forward(void);
void Stop(void);
void Bakcward(void);
void Left(void);
void Right(void);
void setPWMA(int value);
void setPWMB(int value);

#endif

