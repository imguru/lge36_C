#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
typedef struct _monitor_packet {
	char *base;
	char *ptr;
	char *rptr;
} MPacket;

void init_packet(MPacket *mpacket, char *buf){
	mpacket->base = buf;
	mpacket->rptr = buf;

	mpacket->ptr = buf+sizeof(short);
}
int get_int32(MPacket *mpacket){
	int ret = *(int*)mpacket->rptr;
	mpacket->rptr += sizeof(int);
	return ntohl(ret);
}

int get_int16(MPacket *mpacket){
	int ret = *(int *)mpacket->rptr;
	mpacket->rptr += sizeof(short);
	return ntohl(ret);
}


typedef struct _packet{
	unsigned int pwma;
	unsigned int pwmb;
	unsigned int ain;
	unsigned int bin;
}packet;
int Create_Client_Socket(int port) {
	int csock = socket(PF_INET, SOCK_STREAM, 0);
	if (csock == -1) {
		perror("socket");
		exit(1);
	}
	struct sockaddr_in saddr = {0, };
	saddr.sin_family = AF_INET;
	saddr.sin_addr.s_addr = inet_addr("192.168.0.161");
	saddr.sin_port = htons(port);
	if(connect(csock, (struct sockaddr *)&saddr, sizeof saddr) == -1) {
		perror("connect");
		exit(1);
	}
	return csock;
}
ssize_t readn(int fd, void *vptr, size_t n) {
	size_t nleft;
	ssize_t nread;
	char *ptr;
	ptr = vptr;
	nleft = n;
	while (nleft > 0) {
		if((nread = read(fd, ptr, nleft)) < 0) {
			if(errno = EINTR) nread = 0;
			else return -1;
		}
		else if (nread == 0) break;
		nleft -= nread;
		ptr += nread;
	}
	return (n - nleft);
}

void *Monitor_Thread(void *arg) {
	int csock = (intptr_t)arg;
	packet ptmp;
	char buf[512];
	int ret;
	while (1) {
		
		while(ret = readn(csock, &ptmp, sizeof ptmp) >= 0){

			if (ret == 0){
				printf("연결이 종료되었습니다.\n");
				break;
			}
			else if ( ret == -1 ){
				perror("read");
				break;
			}

			char dirA, dirB;
			if ( ptmp.ain == 0 ){
				dirA = 'F';
			}
			else {
				dirA = 'B';
			}
			if ( ptmp.bin == 0 ){
				dirB = 'F';
			}
			else {
				dirB = 'B';
			}
			printf("PWMA : %d(%c) PWMB : %d(%c)\n", ptmp.pwma, dirA, ptmp.pwmb, dirB);
		}
	}
	
	close(csock);
	return 0;
}
int main() {
	int ret;
	char buf[64];
	int temp;
	int m_sock = Create_Client_Socket(5000);
	pthread_t thread;
	intptr_t arg = m_sock;
	int i = 0;
	packet ptmp;
//	pthread_create(&thread, NULL, &Monitor_Thread, (void *)arg);
printf("connnected....\n");
	while(1){
		char *p;
		short len;
		ret= readn(m_sock, &ptmp, sizeof ptmp);
		/*
		if(ret <=0 ) break;

		len = ntohs(*(short *)buf);
		ret = readn(m_sock, buf, len);
		if(ret <= 0) break;

		init_packet(&mpacket, buf);
		int temp = get_int32(&mpacket);
		printf("%d\n", temp);
		*/
		char dirA = 'F';
		char dirB = 'F';
		if ( ptmp.ain == 1){
			dirA = 'B';
		}
		if( ptmp.bin==1){
			dirB = 'B';
		}
		printf("speed : %d(%c) %d(%c)\n", ptmp.pwma, dirA, ptmp.pwmb, dirB);
		}
//	pthread_join(thread, NULL);
	close(m_sock);
//	pthread_detach(thread);
	return 0;
}
 
