#ifndef _PROTOCOL_H
#define _PROTOCOL_H

#define LINE 0
#define MAZE 1
#define HIND 2

typedef struct _packet{
	unsigned int pwma;
	unsigned int pwmb;
	int status;
}packet;

#endif