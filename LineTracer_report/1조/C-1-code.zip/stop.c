#include <wiringPi.h>
#include <stdlib.h>
#include <unistd.h>
#include <softPwm.h>
#include <stdio.h>

#define PWMA 22
#define AIN2 23
#define AIN1 26

#define PWMB 25 
#define BIN1 28
#define BIN2 29

#define CS 21
#define CLOCK 6
#define ADDR 5
#define DOUT 4
#define BUTTON 11
#define NUMSENSOR 5

void setup(void){
	wiringPiSetup();

	pinMode(PWMA, OUTPUT);
	pinMode(AIN2, OUTPUT);
	pinMode(AIN1, OUTPUT);

	pinMode(PWMB, OUTPUT);
	pinMode(BIN2, OUTPUT);
	pinMode(BIN1, OUTPUT);
	
	softPwmCreate(PWMA, 0, 100);
	softPwmCreate(PWMB, 0, 100);
}


void forward(int speed){

	softPwmWrite(PWMB, speed);
	digitalWrite(AIN1, LOW);
	digitalWrite(AIN2, HIGH);
	digitalWrite(BIN1, LOW);
	digitalWrite(BIN2, HIGH);

}

void backward(int speed){
	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);
	digitalWrite(AIN1, HIGH);
	digitalWrite(AIN2, LOW);
	digitalWrite(BIN1, HIGH);
	digitalWrite(BIN2, LOW);
}

void right(int speed){
	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);
	digitalWrite(AIN1, LOW);
	digitalWrite(AIN2, HIGH);
	digitalWrite(BIN1, HIGH);
	digitalWrite(BIN2, LOW);
}

void left(int speed){
	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);
	digitalWrite(AIN1, HIGH);
	digitalWrite(AIN2, LOW);
	digitalWrite(BIN1, LOW);
	digitalWrite(BIN2, HIGH);
}
void stop(void){
	softPwmWrite(PWMA, 0);
	softPwmWrite(PWMB, 0);
	digitalWrite(AIN1, LOW);
	digitalWrite(AIN2, LOW);
	digitalWrite(BIN1, LOW);
	digitalWrite(BIN2, LOW);
}
int main(void){
	
	int* arr;
	setup();
	arr= (int *)malloc(sizeof(int) * 5);	
	//arr = AnalogRead();
	while (1) {	
		stop();
	}

	return 0;
}


