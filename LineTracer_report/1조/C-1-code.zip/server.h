#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdint.h>
//#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
//#include <pthread.h>
//#include <wiringPi.h>
#include <softServo.h>
//#include <softPwm.h>
int Create_Server_Socket(int pot);
void *Monitor_Thread(void *arg);
int openserver(void);

