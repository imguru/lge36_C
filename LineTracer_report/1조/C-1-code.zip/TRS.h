#ifndef TRS_H
#define TRS_H

#include <stdlib.h>
#include <stdio.h>
#include "wiringPi.h"

#define Clock     6
#define Address   5
#define DataOut   4
#define CS        21

#define NUMSENSORS 5

typedef struct _trsensors { 
	int _numSensors;
	int calibratedMin[NUMSENSORS];
	int calibratedMax[NUMSENSORS];
} TRSensors;

TRSensors trs;

void TRSensorSetup();
void AnalogRead(int *sensor_values);
void calibrate();
void readCalibrated(int *sensor_values);
int readLine(int *sensor_values, int white_line);

#endif
