#include "maze.h"
#include "topheader.h"
#include "server.h"
extern packet ptmp;

extern TRSensors trs;
unsigned int sensorValues[NUM_SENSORS];
unsigned long lasttime = 0;
const int maximum = 20;

int fin_flag = 0;

void SetSpeeds(int Aspeed,int Bspeed) {
	ptmp.pwma = Aspeed;
	ptmp.pwmb = Bspeed;
	
	if(Aspeed < 0) {
		digitalWrite(AIN1,HIGH);
		digitalWrite(AIN2,LOW);
		softPwmWrite(PWMA,-Aspeed);      
	}
	else {
		digitalWrite(AIN1,LOW); 
		digitalWrite(AIN2,HIGH);
		softPwmWrite(PWMA,Aspeed);  
	}

	if(Bspeed < 0) {
		digitalWrite(BIN1,HIGH);
		digitalWrite(BIN2,LOW);
		softPwmWrite(PWMB,-Bspeed);      
	}
	else{
		digitalWrite(BIN1,LOW); 
		digitalWrite(BIN2,HIGH);
		softPwmWrite(PWMB,Bspeed);  
	}
}

void msetup() {
	wiringPiSetup();
	TRSensorSetup();

	pinMode(PWMA,OUTPUT);                     
	pinMode(AIN2,OUTPUT);      
	pinMode(AIN1,OUTPUT);
	
	pinMode(PWMB,OUTPUT);       
	pinMode(BIN1,OUTPUT);     
	pinMode(BIN2,OUTPUT);  

	softPwmCreate(PWMA, 0, 100);
	softPwmCreate(PWMB, 0, 100);

	SetSpeeds(0,0);
	
}

void follow_segment() {
	int last_proportional = 0;
	long integral = 0;
	int position;
	int proportional;
	int derivative;
	int power_difference;

	while (1) {
		position = readLine(sensorValues, 0);

		proportional = position - 2000;
		derivative = proportional - last_proportional;
		integral += proportional;
		last_proportional = proportional;

		power_difference = proportional/30 + integral/10000 + derivative*2;

		if (power_difference > maximum)
			power_difference = maximum;
		if (power_difference < -maximum)
			power_difference = -maximum;

		if (power_difference < 0){
			softPwmWrite(PWMA,maximum + power_difference);
			softPwmWrite(PWMB,maximum);
		}
		else{
			softPwmWrite(PWMA,maximum);
			softPwmWrite(PWMB,maximum - power_difference);
		}

		if (millis() - lasttime > 30) { //delay
			if (sensorValues[1] < 150 && sensorValues[2] < 150 
					&& sensorValues[3] < 150) {
				return;
			}
			else if (sensorValues[0] > 600 || sensorValues[4] > 600){
				return;
			}
		}
	}
}

void turn(char dir) {
	switch (dir) {
		case 'L':
			SetSpeeds(-20, 20);
			delay(200);
			break;
		case 'R':
			SetSpeeds(20, -20);
			delay(200);
			break;
		case 'B':
			SetSpeeds(20, -20);
			delay(800);
			break;
		case 'S':
			break;
	}
	SetSpeeds(0, 0);
	lasttime = millis();   
}

char select_turn(unsigned char found_left, unsigned char found_straight, unsigned char found_right) {
	if (found_left)
		return 'L';
	else if (found_straight)
		return 'S';
	else if (found_right)
		return 'R';
	else
		return 'B';
}

void motor(void) {
	char dir;

	msetup();
//	openserver();
	while (1) {
		while (1) {
			follow_segment();

			SetSpeeds(20, 20);
			delay(15);

			unsigned char found_left = 0;
			unsigned char found_straight = 0;
			unsigned char found_right = 0;

			readLine(sensorValues, 0);

			if (sensorValues[0] > 600)
				found_left = 1;
			if (sensorValues[4] > 600)
				found_right = 1;

			//SetSpeeds(20, 20);
			//delay(120);

			//readLine(sensorValues, 0);
			if (sensorValues[1] > 600 || sensorValues[2] > 600 
					|| sensorValues[3] > 600)
				found_straight = 1;

			if (sensorValues[1] > 600 && sensorValues[2] > 600 
					&& sensorValues[3] > 600 && sensorValues[0] > 600
					&& sensorValues[4] > 600) {
				//SetSpeeds(0, 0);
				//break;
				fin_flag++;
				if (fin_flag > 4) {
					SetSpeeds(0, 0);
					break;
				}
				continue;
			}
			
			fin_flag = 0;
			dir = select_turn(found_left, found_straight, found_right);
			//printf("%c\n", dir);
			turn(dir);
//// ###read부분 추
			
		//	ptmp.pwma = (int)digitalRead(PWMA);
		//	ptmp.pwmb = (int)digitalRead(PWMB);
			ptmp.ain = digitalRead(AIN1);
			ptmp.bin = digitalRead(BIN1);
			printf("읽음: %d %d %d %d!\n", ptmp.pwma, ptmp.pwmb, ptmp.ain, ptmp.bin);
		
		}
		getchar();
	}
	return;
}
