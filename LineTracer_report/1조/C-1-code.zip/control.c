// gcc control.c line_tracking.c maze.c (obstacle.c??) -lwiringPi
#include <errno.h>
#include <stdlib.h>
#include "topheader.h"
#include "maze.h"
#include "linetracking.h"
#include "obstacle.h"
#include "server.h"
int mode;
packet ptmp;
void *thread_handler(void *arg){
	switch( mode ){
	
		case 0:
			printf("Start Line Tracking\n");
			line_tracking();
			
			break;
		case 1:
			printf("Start Maze Solver\n");
			motor();
			//openserver();
			break;
		case 2 :
			printf("Start Avoding Obstacles\n");
			findObstacle();
			break;
	}


	return 0;
}

int main(int argc, char* argv[]) {
	
	if (argc == 1 ){
		perror("No argument : 0 - Line Tracing, 1 - Maze Escape, 2 - Obstacle Detection");
		exit(1);
	}

	else if ( argc > 2){
		perror("Too many arguments : 0 - Line Tracing, 1 - Maze Escape, 2 - Obstacle Detection");
		exit(1);
	}

	mode = atoi(argv[1]);

	int m_sock = Create_Server_Socket(5000);
//	printf("created\n");	
	pthread_t mthread;
	pthread_create(&mthread, NULL, thread_handler, NULL);
	pthread_detach(mthread);

	while(1){
		struct sockaddr_in caddr = {0, };
		socklen_t caddrlen = sizeof caddr;
		int csock = accept(m_sock, (struct sockaddr *)&caddr, &caddrlen);
		if (csock == -1) {
			perror("accept");
			return 1;
		}

		printf("client: %s\n", inet_ntoa(caddr.sin_addr));

		pthread_t thread;
		intptr_t arg = csock;

		if (pthread_create(&thread, NULL, Monitor_Thread, (void *)arg) < 0){
			perror("thread create error");
			exit(1);
		}


		pthread_detach(thread);
	}
	close(m_sock);
	return 0;
}

