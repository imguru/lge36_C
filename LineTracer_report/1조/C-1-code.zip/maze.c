
#include "maze.h"
#include "topheader.h"
#include "server.h"
extern packet ptmp;

extern TRSensors trs;
unsigned int sensorValues[NUM_SENSORS];
unsigned long lasttime = 0;
const int maximum = 30;
int fin_flag = 0;

void SetSpeeds(int Aspeed,int Bspeed) {
	
	ptmp.pwma = Aspeed;
	ptmp.pwmb = Bspeed;
	if(Aspeed < 0) {
		digitalWrite(AIN1,HIGH);
		digitalWrite(AIN2,LOW);
		softPwmWrite(PWMA,-Aspeed);      
	}
	else {
		digitalWrite(AIN1,LOW); 
		digitalWrite(AIN2,HIGH);
		softPwmWrite(PWMA,Aspeed);  
	}

	if(Bspeed < 0) {
		digitalWrite(BIN1,HIGH);
		digitalWrite(BIN2,LOW);
		softPwmWrite(PWMB,-Bspeed);      
	}
	else{
		digitalWrite(BIN1,LOW); 
		digitalWrite(BIN2,HIGH);
		softPwmWrite(PWMB,Bspeed);  
	}
}

void msetup() {
	int i;
	wiringPiSetup();
	TRSensorSetup();

	pinMode(PWMA,OUTPUT);                     
	pinMode(AIN2,OUTPUT);      
	pinMode(AIN1,OUTPUT);

	pinMode(PWMB,OUTPUT);       
	pinMode(BIN1,OUTPUT);     
	pinMode(BIN2,OUTPUT);  

	softPwmCreate(PWMA, 0, 100);
	softPwmCreate(PWMB, 0, 100);

	for (i = 0; i < 100; i++) {
		if (i < 25 || i >= 80) {
			digitalWrite(AIN1, HIGH);
			digitalWrite(AIN2, LOW);
			digitalWrite(BIN1, LOW);
			digitalWrite(BIN2, HIGH);
		}	
		else {
			digitalWrite(AIN1, LOW);
			digitalWrite(AIN2, HIGH);
			digitalWrite(BIN1, HIGH);
			digitalWrite(BIN2, LOW);
		}
		softPwmWrite(PWMA, 10);
		softPwmWrite(PWMB, 10);
		calibrate();
	}

	SetSpeeds(0,0);
}

void follow_segment() {
	int last_proportional = 0;
	long integral = 0;
	int position;
	int proportional;
	int derivative;
	int power_difference;

	while (1) {
		position = readLine(sensorValues, 0);

		proportional = position - 2000;
		derivative = proportional - last_proportional;
		integral += proportional;
		last_proportional = proportional;

		power_difference = proportional/30 + integral/10000 + derivative*2;

		if (power_difference > maximum)
			power_difference = maximum;
		if (power_difference < -maximum)
			power_difference = -maximum;

		if (sensorValues[1] < 150 && sensorValues[2] < 150 
				&& sensorValues[3] < 150) {
			return;
		}
		else if (sensorValues[0] > 600 || sensorValues[4] > 600){
			return;
		}

		if (power_difference < 0){
			softPwmWrite(PWMA,maximum + power_difference);
			softPwmWrite(PWMB,maximum);
		}
		else{
			softPwmWrite(PWMA,maximum);
			softPwmWrite(PWMB,maximum - power_difference);
		}
	}
}

void turn(char dir) {
	switch (dir) {
		case 'L':
			SetSpeeds(-20, 20);
			delay(200);
			break;
		case 'R':
			SetSpeeds(20, -20);
			delay(200);
			break;
		case 'B':
			SetSpeeds(20, -20);
			delay(800);
			break;
		case 'S':
			break;
	}
	SetSpeeds(0, 0);
}

char select_turn(char found_left, char found_straight, char found_right) {
	if (found_left)
		return 'L';
	else if (found_straight)
		return 'S';
	else if (found_right)
		return 'R';
	else
		return 'B';
}

void motor(void) {
	char dir;
	int i;

	msetup();

	while (1) {
		while (1) {
			follow_segment();

			char found_left = 0;
			char found_straight = 0;
			char found_right = 0;

			readLine(sensorValues, 0);
			if (sensorValues[1] > 600 && sensorValues[2] > 600 
					&& sensorValues[3] > 600) {// && sensorValues[0] > 600
				fin_flag = 0;
				for (i = 0; i < 3; i++) {
					SetSpeeds(15, 15);
					delay(20);
					readLine(sensorValues, 0);
					if (sensorValues[1] > 600 && sensorValues[2] > 600 
						&& sensorValues[3] > 600) {// && sensorValues[0] > 600
						fin_flag++;	
					}
					else break;
					printf("%d\n", fin_flag);
					SetSpeeds(0, 0);
				}
				if (fin_flag == 3) break;
				
			}

			if (sensorValues[0] > 600)
				found_left = 1;
			if (sensorValues[4] > 600)
				found_right = 1;

			readLine(sensorValues, 0);
			if (sensorValues[1] > 600 || sensorValues[2] > 600 
					|| sensorValues[3] > 600)
				found_straight = 1;

			dir = select_turn(found_left, found_straight, found_right);
			turn(dir);

			ptmp.ain = digitalRead(AIN1);
			ptmp.bin = digitalRead(BIN1);
			printf("읽음: %d %d %d %d!\n", ptmp.pwma, ptmp.pwmb, ptmp.ain, ptmp.bin);

		}
		//getchar();
	}
	return ;
}
