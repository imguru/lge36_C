#include "linetracking.h"
#include "topheader.h"

unsigned int sensorValues[NUM_SENSORS];
unsigned int last_proportional = 0;
int integral = 0;
const int maximum = 70;
extern TRSensors trs;

void forward() {
	digitalWrite(AIN1,LOW);
	digitalWrite(AIN2,HIGH);
	digitalWrite(BIN1,LOW); 
	digitalWrite(BIN2,HIGH);  
	softPwmWrite(PWMA, 0);
	softPwmWrite(PWMB, 0);	
}

void setup() {
	int i;
	
	wiringPiSetup();
	TRSensorSetup();
	
	pinMode(PWMA,OUTPUT);                     
	pinMode(AIN2,OUTPUT);      
	pinMode(AIN1,OUTPUT);
	
	pinMode(PWMB,OUTPUT);       
	pinMode(BIN1,OUTPUT);     
	pinMode(BIN2,OUTPUT);  
	
	softPwmCreate(PWMA, 0, 100);
	softPwmCreate(PWMB, 0, 100);

	for (i = 0; i < 100; i++) {
		if (i < 25 || i >= 85) {
			digitalWrite(AIN1, HIGH);
			digitalWrite(AIN2, LOW);
			digitalWrite(BIN1, LOW);
			digitalWrite(BIN2, HIGH);
			softPwmWrite(PWMA, 10);
			softPwmWrite(PWMB, 10);
		}
		else {
			digitalWrite(AIN1, LOW);
			digitalWrite(AIN2, HIGH);
			digitalWrite(BIN1, HIGH);
			digitalWrite(BIN2, LOW);
			softPwmWrite(PWMA, 10);
			softPwmWrite(PWMB, 10);
		}
		calibrate();
	}
	softPwmWrite(PWMA, 0);
	softPwmWrite(PWMB, 0);	

	forward();
}

int main() {
	int position;
	int proportional;
	int derivative;
	int power_difference;

	setup();
	
	getchar();
	while(1){
		position = readLine(sensorValues, 0);

		if (sensorValues[0] > 900 && sensorValues[1] > 900 
				&& sensorValues[2] > 900 && sensorValues[3] > 900 
				&& sensorValues[4] > 900) {
			softPwmWrite(PWMA, 0);
			softPwmWrite(PWMB, 0);
			continue;
		}

		proportional = position - 2000;

		derivative = proportional - last_proportional;
		integral += proportional;

		last_proportional = proportional;

		power_difference = proportional/30+ integral/10000 + derivative*2;

		if (power_difference > maximum)
			power_difference = maximum;
		if (power_difference < -maximum)
			power_difference = -maximum;

		printf("%d %d\n", position, power_difference);

		if (power_difference < 0) {
			softPwmWrite(PWMA,maximum + power_difference);
			softPwmWrite(PWMB,maximum);
		}
		else {
			softPwmWrite(PWMA,maximum);
			softPwmWrite(PWMB,maximum - power_difference);
		}
		//delayMicroseconds(725);
		//delay(1);
	}	
}

