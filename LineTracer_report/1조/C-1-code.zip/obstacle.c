#include "obstacle.h"
#include "topheader.h"
#include <softTone.h>

#define DSL 27
#define DSR 24
#define SPKR 7

extern packet ptmp;

void oforward(int speed) {

	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);
	
	digitalWrite(AIN1,LOW);
	digitalWrite(AIN2,HIGH);
	digitalWrite(BIN1,LOW); 
	digitalWrite(BIN2,HIGH);  
}

void obackward(int speed){
	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);

	digitalWrite(AIN1, HIGH);
	digitalWrite(AIN2, LOW);
	digitalWrite(BIN1, HIGH);
	digitalWrite(BIN2, LOW);
}

void oright(int speed){

	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);

	digitalWrite(AIN1, LOW);
	digitalWrite(AIN2, HIGH);
	digitalWrite(BIN1, HIGH);
	digitalWrite(BIN2, LOW);
}


void oleft(int speed){

	softPwmWrite(PWMA, speed);
	softPwmWrite(PWMB, speed);

	digitalWrite(AIN1, HIGH);
	digitalWrite(AIN2, LOW);
	digitalWrite(BIN1, LOW);
	digitalWrite(BIN2, HIGH);
}

void ostop(){

	softPwmWrite(PWMA, 0);
	softPwmWrite(PWMB, 0);

	digitalWrite(AIN1, LOW);
	digitalWrite(AIN2, LOW);
	digitalWrite(BIN1, LOW);
	digitalWrite(BIN2, LOW);
}

void osetup() {
	int i;

	wiringPiSetup();

	pinMode(DSL, INPUT);
	pinMode(DSR, INPUT);
	pinMode(SPKR, OUTPUT);

	pullUpDnControl(DSL,0);
	pullUpDnControl(DSR,0);
	pinMode(PWMA,OUTPUT);                     
	pinMode(AIN2,OUTPUT);      
	pinMode(AIN1,OUTPUT);

	pinMode(PWMB,OUTPUT);       
	pinMode(BIN1,OUTPUT);     
	pinMode(BIN2,OUTPUT);  

	softPwmCreate(PWMA, 0, 100);
	softPwmCreate(PWMB, 0, 100);

	oforward(20);
}

void findObstacle(void){	
	int DSL_status = -1;
	int DSR_status = -1;
	
	osetup();	
	
	while(1) {
		oforward(20);
		DSL_status = digitalRead(DSL);	
		DSR_status = digitalRead(DSR);
		
		ptmp.pwma = DSL_status;
		ptmp.pwmb = DSR_status;
		//ptmp.ain = 0;
		//ptmp.bin = 0;
		if (DSL_status == 0 && DSR_status == 0){
			ostop();
		}else if (DSL_status == 0){
			oright(20);
			warningAlarm();
		}else if (DSR_status == 0){
			oleft(20);
			warningAlarm();
		}else{
		}
	}
}


void warningAlarm(){
	int i;
	int DSL_status = 0;
	int DSR_status = 0;

	softToneCreate(SPKR);
	while (1){
		printf("알람 출력중 \n");

		softToneWrite(SPKR, 400);
		delay(200);

		DSL_status = digitalRead(DSL);
		DSR_status = digitalRead(DSR);

		if (DSL_status == 1 && DSR_status == 1){
			softToneWrite(SPKR, 0);
			delay(280);
			break;
		}
	}
	return ;
}
