#include "TRS.h"

extern TRSensors trs;
int last_value = 0; // assume initially that the line is left.

void TRSensorSetup(){
	int i;

	pinMode(Clock, OUTPUT);
	pinMode(Address, OUTPUT);
	pinMode(CS, OUTPUT);  
	pinMode(DataOut, INPUT);
	pullUpDnControl(DataOut, PUD_UP);

	trs._numSensors = NUMSENSORS;
	
	for (i = 0; i < trs._numSensors; i++){
		trs.calibratedMin[i] = 0;
		trs.calibratedMax[i] = 1023;
	}
}

void AnalogRead(int *sensor_values) {
	int i,j;
	int values[NUMSENSORS + 1] = {0,};

	for (j = 0; j < trs._numSensors + 1; j++) {
		digitalWrite(CS,LOW);
		for (i = 0; i < 4; i++) {
			//0 to 4 clock transfer channel address
			if ((j >> (3 - i)) & 0x01)
				digitalWrite(Address,HIGH);
			else
				digitalWrite(Address,LOW);
			
			//0 to10 clock receives the previous conversion result
			values[j] <<= 1;
			if (digitalRead(DataOut)) 
				values[j] |= 0x01;
			digitalWrite(Clock,HIGH);
			digitalWrite(Clock,LOW);
		}
		//sent 11 to 16 clock 
		for (i = 0; i < 6 ; i++) {
			values[j] <<= 1;
			if (digitalRead(DataOut))
				values[j] |= 0x01;
			digitalWrite(Clock,HIGH);
			digitalWrite(Clock,LOW);
		}
		delay(1);
		//delayMicroseconds(250);
		digitalWrite(CS, HIGH);
	}

	for (i = 0; i < trs._numSensors; i++) {
		sensor_values[i] = values[i + 1];
//		printf("%d ", sensor_values[i]);
	}
//	printf("\n");
}

void calibrate() {
	int i, j;
	int sensor_values[NUMSENSORS] = {0, };
	int max_sensor_values[NUMSENSORS] = {0, };
	int min_sensor_values[NUMSENSORS] = {0, };

	for (j = 0; j < 10; j++) {
		AnalogRead(sensor_values);
		for (i = 0; i < trs._numSensors; i++) {
			// set the max we found THIS time
			if (j == 0 || max_sensor_values[i] < sensor_values[i])
				max_sensor_values[i] = sensor_values[i];

			// set the min we found THIS time
			if (j == 0 || min_sensor_values[i] > sensor_values[i])
				min_sensor_values[i] = sensor_values[i];
		}
	}

	// record the min and max calibration values
	for (i = 0; i < trs._numSensors; i++) {
		if (min_sensor_values[i] > trs.calibratedMin[i])
			trs.calibratedMin[i] = min_sensor_values[i];
		
		if (max_sensor_values[i] < trs.calibratedMax[i])
			trs.calibratedMax[i] = max_sensor_values[i];
	}
}

void readCalibrated(int *sensor_values) {
	int i;
	int value = 0;
	int denominator;

	// read the needed values
	AnalogRead(sensor_values);

	for (i = 0; i < trs._numSensors; i++) {
		denominator = trs.calibratedMax[i] - trs.calibratedMin[i];

		if (denominator != 0)
			value = (sensor_values[i] - trs.calibratedMin[i])* 1000. / denominator;
		if (value < 0)	value = 0;
		else if (value > 1000)	value = 1000;
		sensor_values[i] = (int)value;
	}
}

int readLine(int *sensor_values, int white_line) {
	int i, on_line = 0;
	int avg=0; // this is for the weighted total, which is long
	int sum=0; // this is for the denominator which is <= 64000

	readCalibrated(sensor_values);

	for (i = 0; i < trs._numSensors; i++) {
		int value = sensor_values[i];
		if(white_line)
			value = 1000 - value;
		
		// keep track of whether we see the line at all
		if (value > 200) {
			on_line = 1;
		}

		// only average in values that are above a noise threshold
		if (value > 50) {
			avg += value * (i * 1000);
			sum += value;
		}
	}

	if (on_line != 1) {
		// If it last read to the left of center, return 0.
		if (last_value < (trs._numSensors - 1) * 1000 / 2)
			return 0;

		// If it last read to the right of center, return the max.
		else
			return (trs._numSensors - 1) * 1000;
	}

	last_value = avg/sum;
	//printf("%d\n", last_value);

	return last_value;
}
