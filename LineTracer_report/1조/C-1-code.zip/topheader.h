#ifndef _TOPHEADER_H
#define _TOPHEADER_H
#include "TRS.h"
#include <wiringPi.h>
#include <softPwm.h>
#include <stdio.h>
#include <pthread.h>

#define PWMA   22           //Left Motor Speed pin (ENA)
#define AIN2   23          //Motor-L forward (IN2).
#define AIN1   26          //Motor-L backward (IN1)

#define PWMB   25           //Right Motor Speed pin (ENB)
#define BIN1   28          //Motor-R forward (IN3)
#define BIN2   29          //Motor-R backward (IN4)
#define NUM_SENSORS 5


typedef struct _packet{
	int pwma;
	int pwmb;
	unsigned int ain;
	unsigned int bin;
}packet;
#endif
