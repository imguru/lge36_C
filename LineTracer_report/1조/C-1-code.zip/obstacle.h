#ifndef _OBSTACLE_H
#define _OBSTACLE_H

void findObstacle(void);
void warningAlarm(void);
void oforward(int speed);
void obackward(int speed);
void oleft(int speed);
void oright(int speed);
void ostop(void);
void osetup(void);
#endif
