#include "server.h"
#include "topheader.h"

typedef struct _monitor_packet {
	char *base;
	char *ptr;
} MPacket;


int sock;
extern packet ptmp;
ssize_t Write(int fd, const void *buf, size_t count)
{
	int ret;
	ret = write(fd, buf, count);
	if (ret < 0){
		perror("write");
		exit(1);
	}

	return ret;
}
int Create_Server_Socket(int port) {
	int i, j;
	int ssock = socket(PF_INET, SOCK_STREAM, 0);
	if (ssock == -1) {
		perror("socket");
		exit(1);
	}
	int option = 1;
	setsockopt(ssock, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));
	struct sockaddr_in saddr = {0, };
	saddr.sin_family = AF_INET;
	saddr.sin_addr.s_addr = INADDR_ANY;
	saddr.sin_port = htons(port);
	if (bind(ssock, (struct sockaddr *)&saddr, sizeof saddr) == -1) {
		perror("bind");
		exit(1);
	}
	if (listen(ssock, SOMAXCONN) == -1) {
		perror("listen");
		exit(1);
	}
	return ssock;
}

void *Monitor_Thread(void *arg) {
	int csock = (intptr_t)arg; 
	MPacket packet;
	while(1){
		char tmp1 = 'F';
		char tmp2 = 'F';
		/*
		if (ptmp.ain){
			tmp1 = 'B';
		}
		if(ptmp.bin){
			tmp2 = 'B';
		}
		printf("속도: %d (%c) 속도: %d (%c)\n", ptmp.pwma, tmp1, ptmp.pwmb, tmp2);
		*/
		
		//write(sock, pp, sizeof pp);
		//printf("여기까지");
		write(csock, &ptmp, sizeof (ptmp));
		sleep(1);

		//sleep(5);
	}
	close(csock);
	printf("클라이언트와 연결이 종료되었습니다..\n");

	return 0;
}

