#ifndef _LINETRACKING_H
#define _LINETRACKING_H

#define NUM_SENSORS 5
#define PWMA   22           //Left Motor Speed pin (ENA)
#define AIN2   23          //Motor-L forward (IN2).
#define AIN1   26          //Motor-L backward (IN1)

#define PWMB   25           //Right Motor Speed pin (ENB)
#define BIN1   28          //Motor-R forward (IN3)
#define BIN2   29          //Motor-R backward (IN4)

void forward(void);
void setup(void);
void line_tracking(void);

#endif

