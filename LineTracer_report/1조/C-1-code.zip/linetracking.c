#include "linetracking.h"
#include "topheader.h"

unsigned int sensorValues[NUM_SENSORS];
unsigned int last_proportional = 0;
long integral = 0;
const int max = 25;
extern TRSensors trs;

void forward() {
	digitalWrite(AIN1,LOW);
	digitalWrite(AIN2,HIGH);
	digitalWrite(BIN1,LOW); 
	digitalWrite(BIN2,HIGH);  
	softPwmWrite(PWMA, 0);
	softPwmWrite(PWMB, 0);	
}

void setup() {
	int i;
	
	wiringPiSetup();
	
	pinMode(PWMA,OUTPUT);                     
	pinMode(AIN2,OUTPUT);      
	pinMode(AIN1,OUTPUT);
	
	pinMode(PWMB,OUTPUT);       
	pinMode(BIN1,OUTPUT);     
	pinMode(BIN2,OUTPUT);  
	
	softPwmCreate(PWMA, 0, 100);
	softPwmCreate(PWMB, 0, 100);
	
	forward();

	TRSensorSetup();
	
	printf("calibrate done\n");

	for (i = 0; i < NUM_SENSORS; i++){
		printf("%d ", trs.calibratedMin[i]);
	}
	printf("\n");

	for (i = 0; i < NUM_SENSORS; i++) {
		printf("%d ", trs.calibratedMax[i]);
	}
	printf("\n");
}

void line_tracking() {
	int position;
	int proportional;
	int derivative;
	int power_difference;

	setup();

	while(1){
		position = readLine(sensorValues, 0);
		
		if (sensorValues[0] > 900 && sensorValues[1] > 900 
				&& sensorValues[2] > 900 && sensorValues[3] > 900 
				&& sensorValues[4] > 900) {
			softPwmWrite(PWMA, 0);
			softPwmWrite(PWMB, 0);
			continue;
		}

		proportional = position - 2000;

		derivative = proportional - last_proportional;
		integral += proportional;

		last_proportional = proportional;

		power_difference = proportional/30 + integral/10000 + derivative*2;

		if (power_difference > max)
			power_difference = max;
		if (power_difference < -max)
			power_difference = -max;
		
		printf("%d %d\n", position, power_difference);
		
		if (power_difference < 0) {
			softPwmWrite(PWMA,max + power_difference);
			softPwmWrite(PWMB,max);
		}
		else {
			softPwmWrite(PWMA,max);
			softPwmWrite(PWMB,max - power_difference);
		}
	}
	
}

