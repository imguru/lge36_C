#ifndef _MAZE_H
#define _MAZE_H

void SetSpeeds(int Aspeed, int Bspeed);
void msetup(void);
void follow_segment(void);
void turn(char dir);
void motor(void);

char select_turn(char found_left,char found_straight, char found_right);

#endif
